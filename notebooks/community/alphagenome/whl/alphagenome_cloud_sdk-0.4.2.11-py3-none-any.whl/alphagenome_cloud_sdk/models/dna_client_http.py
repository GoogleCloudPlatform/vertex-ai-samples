# Copyright 2025 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Client implementation for interacting with a DNA model server over HTTP."""

from collections.abc import Container, Iterable, Iterator, Sequence
import concurrent.futures
import dataclasses
import functools
import json
import random
import time
from typing import Any, cast
from typing import Generator, TypeVar
from alphagenome.data import genome
from alphagenome.data import junction_data
from alphagenome.data import ontology
from alphagenome.data import track_data
from alphagenome.models import dna_client
from alphagenome.models import dna_model
from alphagenome.models import dna_output
from alphagenome.models import interval_scorers as interval_scorers_lib
from alphagenome.models import variant_scorers as variant_scorers_lib
from alphagenome.protos import dna_model_pb2
from alphagenome.protos import dna_model_service_pb2
import anndata
import google.auth
from google.auth import impersonated_credentials
import google.auth.transport.requests
from google.protobuf import json_format
import httpx
import pandas as pd
import tqdm.auto

# Maximum width of an in silico mutagenesis (ISM) interval request.
MAX_ISM_INTERVAL_WIDTH = 10

# Maximum number of variant scorers per request.
MAX_VARIANT_SCORERS_PER_REQUEST = 20

_RetryableFunction = TypeVar('_RetryableFunction')


def _format_ontology_terms_for_json(
    ontology_terms: Iterable[ontology.OntologyTerm | str] | None,
) -> list[dict[str, str]] | None:
  """Formats ontology terms into the JSON structure expected by the endpoint."""
  if ontology_terms is None:
    return None

  formatted_terms = []
  for term in dict.fromkeys(
      ontology_terms
  ):  # Use dict.fromkeys to ensure uniqueness
    if isinstance(term, ontology.OntologyTerm):
      # Assuming ontology.OntologyTerm has .ontology_type (an enum) and .id (a string)
      formatted_terms.append(
          {'ontology_type': f'ONTOLOGY_TYPE_{term.type.name}', 'id': term.id}
      )
    else:  # Assume it's a CURIE string
      # Convert CURIE string to OntologyTerm object first
      ont_term_obj = ontology.from_curie(term)
      formatted_terms.append({
          'ontology_type': f'ONTOLOGY_TYPE_{ont_term_obj.type.name}',
          'id': ont_term_obj.id,
      })
  return formatted_terms


def _format_variant_scorers_for_json(
    variant_scorers: Sequence[variant_scorers_lib.VariantScorerTypes],
) -> list[dict[str, dict[str, str | int]]]:
  """Formats variant scorers into the JSON structure expected by the endpoint."""
  formatted_scorers = []
  for scorer in variant_scorers:
    if isinstance(scorer, variant_scorers_lib.CenterMaskScorer):
      payload = {
          'aggregationType': f'AGGREGATION_TYPE_{scorer.aggregation_type.name}',
          'requestedOutput': f'OUTPUT_TYPE_{scorer.requested_output.name}',
      }
      if scorer.width is not None:

        payload['width'] = str(scorer.width)
      formatted_scorers.append({'centerMask': payload})
    elif isinstance(scorer, variant_scorers_lib.GeneMaskLFCScorer):
      formatted_scorers.append({
          'geneMask': {
              'requestedOutput': f'OUTPUT_TYPE_{scorer.requested_output.name}',
          }
      })
    elif isinstance(scorer, variant_scorers_lib.GeneMaskActiveScorer):
      formatted_scorers.append({
          'geneMaskActive': {
              'requestedOutput': f'OUTPUT_TYPE_{scorer.requested_output.name}',
          }
      })
    elif isinstance(scorer, variant_scorers_lib.GeneMaskSplicingScorer):
      payload = {
          'requestedOutput': f'OUTPUT_TYPE_{scorer.requested_output.name}',
      }
      if scorer.width is not None:

        payload['width'] = str(scorer.width)
      formatted_scorers.append({'geneMaskSplicing': payload})

    elif isinstance(scorer, variant_scorers_lib.PolyadenylationScorer):
      formatted_scorers.append({'paQtl': {}})
    elif isinstance(scorer, variant_scorers_lib.SpliceJunctionScorer):
      formatted_scorers.append({'spliceJunction': {}})
    elif isinstance(scorer, variant_scorers_lib.ContactMapScorer):
      formatted_scorers.append({'contactMap': {}})
    else:
      raise ValueError(f'Unsupported variant scorer type: {type(scorer)}')
  return formatted_scorers


def _format_interval_scorers_for_json(
    interval_scorers: Sequence[interval_scorers_lib.IntervalScorerTypes],
) -> list[dict[str, dict[str, str]]]:
  """Formats interval scorers into the JSON structure expected by the endpoint."""
  formatted_scorers = []
  for scorer in interval_scorers:
    if isinstance(scorer, interval_scorers_lib.GeneMaskScorer):

      payload = {
          'requestedOutput': f'OUTPUT_TYPE_{scorer.requested_output.name}',
          'aggregationType': (
              f'INTERVAL_AGGREGATION_TYPE_{scorer.aggregation_type.name}'
          ),
      }

      if scorer.width is not None:
        payload['width'] = str(scorer.width)
      formatted_scorers.append({'geneMask': payload})
    else:
      raise ValueError(f'Unsupported interval scorer type: {type(scorer)}')
  return formatted_scorers


# Supported DNA sequence lengths.
SEQUENCE_LENGTH_16KB = 2**14  # 16_384
SEQUENCE_LENGTH_100KB = 2**17  # 131_072
SEQUENCE_LENGTH_500KB = 2**19  # 524_288
SEQUENCE_LENGTH_1MB = 2**20  # 1_048_576

SUPPORTED_SEQUENCE_LENGTHS = {
    'SEQUENCE_LENGTH_16KB': SEQUENCE_LENGTH_16KB,
    'SEQUENCE_LENGTH_100KB': SEQUENCE_LENGTH_100KB,
    'SEQUENCE_LENGTH_500KB': SEQUENCE_LENGTH_500KB,
    'SEQUENCE_LENGTH_1MB': SEQUENCE_LENGTH_1MB,
}


def validate_sequence_length(length: int):
  """Validate that the input sequence length is supported by the model."""
  if length not in SUPPORTED_SEQUENCE_LENGTHS.values():
    raise ValueError(
        f'Sequence length {length} not supported by the model.'
        f' Supported lengths: {[*SUPPORTED_SEQUENCE_LENGTHS.values()]}'
    )


def _fix_metadata_for_negative_strand(metadata: pd.DataFrame) -> pd.DataFrame:
  """Fixes metadata for negative strand by swapping +/- pairs."""
  df_strands = pd.DataFrame({
      'name': metadata['name'].values,
      'strand': metadata['strand'].values,
      'old_idx': np.arange(len(metadata)),
  })
  df_strands = df_strands[df_strands.strand != genome.STRAND_UNSTRANDED]
  df_strands.sort_values(['strand', 'name'], inplace=True)

  if np.all(df_strands.groupby('name').size() != 2):
    raise ValueError('Not all stranded tracks have both + and - strand.')
  if (df_strands.strand == genome.STRAND_POSITIVE).sum() != (
      df_strands.strand == genome.STRAND_NEGATIVE
  ).sum():
    raise ValueError(
        'We need to have the exact same number of + and - stranded tracks'
    )
  new_idx = df_strands.old_idx.values.reshape((2, -1))[::-1].ravel()
  idx = np.arange(len(metadata))
  idx[df_strands.old_idx.values] = new_idx

  return metadata.iloc[idx]


class HttpDnaClient(dna_model.DnaModel):
  """Client for interacting with a DNA model server over HTTP."""

  def __init__(
      self,
      *,
      http_client: httpx.Client,
      model_version: str | None = None,
      vertex_ai_url: str,
      credentials: google.auth.credentials.Credentials | None = None,
  ):
    self._http_client = http_client
    self._model_version = model_version
    self._vertex_ai_url = vertex_ai_url
    self._credentials = credentials

  def _authenticate(self):
    """Authenticate and get OAuth2 token."""
    if self._credentials is None:
      self._credentials, _ = google.auth.default(
          scopes=[
              'https://www.googleapis.com/auth/cloud-platform',
              'https://www.googleapis.com/auth/cloud-platform.read-only',
          ]
      )
    if not self._credentials.valid:
      self._credentials.refresh(google.auth.transport.requests.Request())

  def validate_credentials(self):
    if not self._credentials or not self._credentials.valid:
      self._authenticate()
    else:
      return 'Credentials are valid.'

  def predict_interval(
      self,
      interval: genome.Interval,
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
      requested_outputs: Iterable[dna_output.OutputType] | None = None,
      ontology_terms: Iterable[ontology.OntologyTerm | str] | None = None,
  ) -> dna_output.Output:
    self._authenticate()
    strand_map = {
        '+': 'STRAND_POSITIVE',
        '-': 'STRAND_NEGATIVE',
        '.': 'STRAND_UNSTRANDED',
    }
    request_body = {
        'instances': [{
            'request_type': 'predict_interval',
            'data': {
                'interval': {
                    'chromosome': interval.chromosome,
                    'start': str(interval.start),
                    'end': str(interval.end),
                    'strand': strand_map.get(
                        str(interval.strand), 'STRAND_UNSTRANDED'
                    ),
                },
                'organism': f'ORGANISM_{organism.name}',
                'requestedOutputs': [
                    f'OUTPUT_TYPE_{o.name}' for o in requested_outputs
                ],
            },
        }]
    }
    formatted_ontology_terms = _format_ontology_terms_for_json(ontology_terms)
    if formatted_ontology_terms:
      request_body['instances'][0]['data'][
          'ontology_terms'
      ] = formatted_ontology_terms
    if self._model_version:
      request_body['instances'][0]['data']['modelVersion'] = self._model_version

    with self._http_client.stream(
        'POST', self._vertex_ai_url, json=request_body
    ) as response:
      response.raise_for_status()
      response_protos = (
          json_format.ParseDict(
              json.loads(line), dna_model_service_pb2.PredictIntervalResponse()
          )
          for line in response.iter_lines()
      )
      return dna_client._make_output(response_protos, interval=interval)

  def predict_variant(
      self,
      interval: genome.Interval,
      variant: genome.Variant,
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
      requested_outputs: Iterable[dna_output.OutputType] | None = None,
      ontology_terms: Iterable[ontology.OntologyTerm | str] | None = None,
      fix_negative_strand: bool = False,
  ) -> dna_output.VariantOutput:
    validate_sequence_length(interval.width)
    self._authenticate()
    strand_map = {
        '+': 'STRAND_POSITIVE',
        '-': 'STRAND_NEGATIVE',
        '.': 'STRAND_UNSTRANDED',
    }

    if fix_negative_strand and interval.negative_strand:
      variant = variant.copy()
      variant.position = (
          interval.end
          - variant.position
          - len(variant.reference_bases)
          + 2
          + interval.start
      )

    request_body = {
        'instances': [{
            'request_type': 'predict_variant',
            'data': {
                'interval': {
                    'chromosome': interval.chromosome,
                    'start': str(interval.start),
                    'end': str(interval.end),
                    'strand': strand_map.get(
                        str(interval.strand), 'STRAND_UNSTRANDED'
                    ),
                },
                'variant': {
                    'chromosome': variant.chromosome,
                    'position': str(variant.position),
                    'referenceBases': variant.reference_bases,
                    'alternateBases': variant.alternate_bases,
                },
                'organism': f'ORGANISM_{organism.name}',
                'requested_outputs': [
                    f'OUTPUT_TYPE_{o.name}' for o in requested_outputs
                ],
            },
        }]
    }
    formatted_ontology_terms = _format_ontology_terms_for_json(ontology_terms)
    if formatted_ontology_terms:
      request_body['instances'][0]['data'][
          'ontology_terms'
      ] = formatted_ontology_terms
    if self._model_version:
      request_body['instances'][0]['data']['modelVersion'] = self._model_version

    # print(f"Request body: {json.dumps(request_body, indent=2)}")

    with self._http_client.stream(
        'POST', self._vertex_ai_url, json=request_body
    ) as response:
      response.raise_for_status()
      response_protos = (
          json_format.ParseDict(
              json.loads(line), dna_model_service_pb2.PredictVariantResponse()
          )
          for line in response.iter_lines()
      )
      variant_output = dna_client._make_variant_output(response_protos)

      if fix_negative_strand and interval.negative_strand:
        variant_output = dna_output.VariantOutput(
            reference=variant_output.reference.map_track_data(
                lambda tdata, _: dataclasses.replace(
                    tdata,
                    metadata=_fix_metadata_for_negative_strand(tdata.metadata),
                )
            ),
            alternate=variant_output.alternate.map_track_data(
                lambda tdata, _: dataclasses.replace(
                    tdata,
                    metadata=_fix_metadata_for_negative_strand(tdata.metadata),
                )
            ),
        )
      return variant_output

  def output_metadata(
      self, organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS
  ) -> dna_output.OutputMetadata:
    """Get the metadata for a given organism.

    Args:
      organism: Organism to get metadata for.

    Returns:
      OutputMetadata for the provided organism.
    """
    self._authenticate()
    request_body = {
        'instances': [{
            'request_type': 'get_metadata',
            'data': {
                'organism': f'ORGANISM_{organism.name}',
            },
        }]
    }

    with self._http_client.stream(
        'POST', self._vertex_ai_url, json=request_body
    ) as response:
      response.raise_for_status()

      response_protos = (
          json_format.ParseDict(
              json.loads(line), dna_model_service_pb2.MetadataResponse()
          )
          for line in response.iter_lines()
      )

      return dna_client.construct_output_metadata(response_protos)

  def predict_sequence(
      self,
      sequence: str,
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
      requested_outputs: Iterable[dna_output.OutputType],
      ontology_terms: Iterable[ontology.OntologyTerm | str] | None,
      interval: genome.Interval | None = None,
  ) -> dna_output.Output:
    self._authenticate()
    _VALID_SEQUENCE_CHARACTERS = frozenset('ACGTN')
    if not (unique_values := set(sequence)).issubset(
        _VALID_SEQUENCE_CHARACTERS
    ):
      invalid_characters = ','.join(unique_values - _VALID_SEQUENCE_CHARACTERS)
      raise ValueError(
          'Invalid sequence, must only contain the characters "ACGTN". Found'
          f' invalid characters: "{invalid_characters}"'
      )
    validate_sequence_length(len(sequence))

    request_body = {
        'instances': [{
            'request_type': 'predict_sequence',
            'data': {
                'sequence': sequence,
                'organism': f'ORGANISM_{organism.name}',
                'requestedOutputs': [
                    f'OUTPUT_TYPE_{o.name}' for o in requested_outputs
                ],
            },
        }]
    }

    formatted_ontology_terms = _format_ontology_terms_for_json(ontology_terms)
    if formatted_ontology_terms:
      request_body['instances'][0]['data'][
          'ontology_terms'
      ] = formatted_ontology_terms
    if self._model_version:
      request_body['instances'][0]['data']['modelVersion'] = self._model_version

    with self._http_client.stream(
        'POST', self._vertex_ai_url, json=request_body
    ) as response:
      response.raise_for_status()
      response_protos = (
          json_format.ParseDict(
              json.loads(line), dna_model_service_pb2.PredictSequenceResponse()
          )
          for line in response.iter_lines()
      )
      return dna_client._make_output(response_protos, interval=interval)

  def score_interval(
      self,
      interval: genome.Interval,
      interval_scorers: Sequence[interval_scorers_lib.IntervalScorerTypes] = (),
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
  ) -> list[anndata.AnnData]:
    self._authenticate()
    if not interval_scorers:
      interval_scorers = list(
          interval_scorers_lib.RECOMMENDED_INTERVAL_SCORERS.values()
      )

    validate_sequence_length(interval.width)
    if len(interval_scorers) != len(set(interval_scorers)):
      raise ValueError(
          f'Duplicate interval scorers requested: {interval_scorers}.'
      )
    if len(interval_scorers) > MAX_VARIANT_SCORERS_PER_REQUEST:
      raise ValueError(
          'Too many interval scorers requested, '
          f'maximum allowed: {MAX_VARIANT_SCORERS_PER_REQUEST}.'
      )
    if any(
        scorer.width is not None and scorer.width > interval.width
        for scorer in interval_scorers
    ):
      raise ValueError('Interval scorers must have widths <= interval width.')

    strand_map = {
        '+': 'STRAND_POSITIVE',
        '-': 'STRAND_NEGATIVE',
        '.': 'STRAND_UNSTRANDED',
    }
    request_body = {
        'instances': [{
            'request_type': 'score_interval',
            'data': {
                'interval': {
                    'chromosome': interval.chromosome,
                    'start': str(interval.start),
                    'end': str(interval.end),
                    'strand': strand_map.get(
                        str(interval.strand), 'STRAND_UNSTRANDED'
                    ),
                },
                'organism': f'ORGANISM_{organism.name}',
                'intervalScorers': _format_interval_scorers_for_json(
                    interval_scorers
                ),
            },
        }]
    }

    if self._model_version:
      request_body['instances'][0]['data']['modelVersion'] = self._model_version

    with self._http_client.stream(
        'POST', self._vertex_ai_url, json=request_body
    ) as response:
      response.raise_for_status()
      response_protos = (
          json_format.ParseDict(
              json.loads(line), dna_model_service_pb2.ScoreIntervalResponse()
          )
          for line in response.iter_lines()
      )
      interval_outputs = dna_client._make_interval_output(
          response_protos, interval
      )
      for ix in range(len(interval_scorers)):
        interval_outputs[ix].uns['interval_scorer'] = interval_scorers[ix]
      return interval_outputs

  def score_variant(
      self,
      interval: genome.Interval,
      variant: genome.Variant,
      variant_scorers: Sequence[variant_scorers_lib.VariantScorerTypes] = (),
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
      fix_negative_strand: bool = False,
  ) -> list[anndata.AnnData]:
    self._authenticate()
    if not variant_scorers:
      variant_scorers = variant_scorers_lib.get_recommended_scorers(
          organism.to_proto()
      )

    validate_sequence_length(interval.width)
    for variant_scorer in variant_scorers:
      supported_organisms = variant_scorers_lib.SUPPORTED_ORGANISMS[
          variant_scorer.base_variant_scorer
      ]
      if organism.to_proto() not in supported_organisms:
        supported_organisms = [
            dna_model_pb2.Organism.Name(o).removeprefix('ORGANISM_')
            for o in supported_organisms
        ]
        raise ValueError(
            f'Unsupported organism: {organism.name} for scorer'
            f' {variant_scorer}. Supported organisms:'
            f' {supported_organisms}'
        )
    if len(variant_scorers) != len(set(variant_scorers)):
      raise ValueError(
          f'Duplicate variant scorers requested: {variant_scorers}.'
      )
    if len(variant_scorers) > MAX_VARIANT_SCORERS_PER_REQUEST:
      raise ValueError(
          'Too many variant scorers requested, '
          f'maximum allowed: {MAX_VARIANT_SCORERS_PER_REQUEST}.'
      )

    strand_map = {
        '+': 'STRAND_POSITIVE',
        '-': 'STRAND_NEGATIVE',
        '.': 'STRAND_UNSTRANDED',
    }

    if fix_negative_strand and interval.negative_strand:
      variant = variant.copy()
      variant.position = (
          interval.end
          - variant.position
          - len(variant.reference_bases)
          + 2
          + interval.start
      )

    request_body = {
        'instances': [{
            'request_type': 'score_variant',
            'data': {
                'interval': {
                    'chromosome': interval.chromosome,
                    'start': str(interval.start),
                    'end': str(interval.end),
                    'strand': strand_map.get(
                        str(interval.strand), 'STRAND_UNSTRANDED'
                    ),
                },
                'variant': {
                    'chromosome': variant.chromosome,
                    'position': str(variant.position),
                    'referenceBases': variant.reference_bases,
                    'alternateBases': variant.alternate_bases,
                },
                'organism': f'ORGANISM_{organism.name}',
                'variantScorers': _format_variant_scorers_for_json(
                    variant_scorers
                ),
            },
        }]
    }

    if self._model_version:
      request_body['instances'][0]['data']['modelVersion'] = self._model_version

    with self._http_client.stream(
        'POST', self._vertex_ai_url, json=request_body
    ) as response:
      response.raise_for_status()
      response_lines = []
      for line in response.iter_lines():
        json_data = json.loads(line)
        response_lines.append(
            json_format.ParseDict(
                json_data, dna_model_service_pb2.ScoreVariantResponse()
            )
        )

      variant_outputs = dna_client._make_score_variant_output(
          iter(response_lines), interval
      )

      if fix_negative_strand and interval.negative_strand:
        for adata in variant_outputs:
          adata.var = _fix_metadata_for_negative_strand(adata.var)

      for ix in range(len(variant_scorers)):
        variant_outputs[ix].uns['variant_scorer'] = variant_scorers[ix]
      return variant_outputs

  def score_ism_variants(
      self,
      interval: genome.Interval,
      ism_interval: genome.Interval,
      variant_scorers: Sequence[variant_scorers_lib.VariantScorerTypes] = (),
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
      progress_bar: bool = True,
      max_workers: int = dna_model.DEFAULT_MAX_WORKERS,
      interval_variant: genome.Variant | None = None,
  ) -> list[list[anndata.AnnData]]:
    """Generate in-silico mutagenesis (ISM) variant scores for a given interval.

    Args:
      interval: DNA interval to make the prediction for.
      ism_interval: Interval to perform ISM.
      variant_scorers: Sequence of variant scorers to use for scoring each
        variant. If no variant scorers are provided, the recommended variant
        scorers for the organism will be used.
      organism: Organism to use for the prediction.
      progress_bar: If True, show a progress bar.
      max_workers: Number of parallel workers to use.
      interval_variant: Optional variant to use as an alternate-allele
        background for the in-silico mutagenesis.

    Returns:
      List of variant scores for each variant in the ISM interval.
    """
    self._authenticate()
    if not variant_scorers:
      variant_scorers = variant_scorers_lib.get_recommended_scorers(
          organism.to_proto()
      )

    validate_sequence_length(interval.width)
    if ism_interval.negative_strand:
      raise ValueError('ISM interval must be on the positive strand.')

    ism_intervals = []
    for position in range(0, ism_interval.width, MAX_ISM_INTERVAL_WIDTH):
      ism_intervals.append(
          genome.Interval(
              ism_interval.chromosome,
              ism_interval.start + position,
              min(
                  ism_interval.start + position + MAX_ISM_INTERVAL_WIDTH,
                  ism_interval.end,
              ),
          )
      )

    @retry_http
    def _score_ism_variant(
        ism_interval: genome.Interval,
    ) -> list[anndata.AnnData]:
      strand_map = {
          '+': 'STRAND_POSITIVE',
          '-': 'STRAND_NEGATIVE',
          '.': 'STRAND_UNSTRANDED',
      }
      request_body = {
          'instances': [{
              'request_type': 'score_ism_variant',
              'data': {
                  'interval': {
                      'chromosome': interval.chromosome,
                      'start': str(interval.start),
                      'end': str(interval.end),
                      'strand': strand_map.get(
                          str(interval.strand), 'STRAND_UNSTRANDED'
                      ),
                  },
                  'ismInterval': {
                      'chromosome': ism_interval.chromosome,
                      'start': str(ism_interval.start),
                      'end': str(ism_interval.end),
                      'strand': strand_map.get(
                          str(ism_interval.strand), 'STRAND_UNSTRANDED'
                      ),
                  },
                  'organism': f'ORGANISM_{organism.name}',
                  'variantScorers': _format_variant_scorers_for_json(
                      variant_scorers
                  ),
              },
          }]
      }

      if interval_variant:
        request_body['instances'][0]['data']['intervalVariant'] = {
            'chromosome': interval_variant.chromosome,
            'position': str(interval_variant.position),
            'referenceBases': interval_variant.reference_bases,
            'alternateBases': interval_variant.alternate_bases,
        }

      if self._model_version:
        request_body['instances'][0]['data'][
            'modelVersion'
        ] = self._model_version

      with self._http_client.stream(
          'POST', self._vertex_ai_url, json=request_body
      ) as response:
        response.raise_for_status()
        response_protos = (
            json_format.ParseDict(
                json.loads(line),
                dna_model_service_pb2.ScoreIsmVariantResponse(),
            )
            for line in response.iter_lines()
        )
        return dna_client._make_score_variant_output(
            response_protos, interval=interval
        )

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=max_workers
    ) as executor:
      futures = [
          executor.submit(_score_ism_variant, ism_interval)
          for ism_interval in ism_intervals
      ]
      ism_scores = []
      for future in tqdm.auto.tqdm(
          concurrent.futures.as_completed(futures),
          total=len(futures),
          disable=not progress_bar,
      ):
        ism_scores.extend(future.result())

    # Group scores by variant.
    ism_scores_by_variant: dict[str, list[anndata.AnnData]] = {}
    for variant_score in ism_scores:
      ism_scores_by_variant.setdefault(
          str(variant_score.uns['variant']), []
      ).append(variant_score)

    return list(ism_scores_by_variant.values())


def retry_http(
    function: _RetryableFunction,
    *,
    max_attempts: int = 5,
    initial_backoff: float = 1.25,
    backoff_multiplier: float = 1.5,
    retry_status_codes: Container[int] = frozenset([429, 503]),
    jitter: float = 0.2,
) -> _RetryableFunction:
  """Decorator that retries when an HTTP request fails with a retryable code.

  Arguments:
    function: Callable to retry.
    max_attempts: Maximum number of attempts to make.
    initial_backoff: Initial backoff time in seconds.
    backoff_multiplier: Backoff multiplier to apply on each retry.
    retry_status_codes: Set of status codes to retry on.
    jitter: Jitter to apply to the backoff time.

  Returns:
    A decorator that retries the function on retryable HTTP errors.
  """
  if backoff_multiplier < 1.0:
    raise ValueError('Backoff multiplier must be >= 1.0.')

  @functools.wraps(function)
  def wrapper(*args, **kwargs):
    attempt = 0
    current_backoff = initial_backoff + (
        random.uniform(-jitter, jitter) * initial_backoff
    )
    while True:
      try:
        attempt += 1
        return function(*args, **kwargs)
      except httpx.HTTPStatusError as e:
        if (
            e.response.status_code not in retry_status_codes
            or attempt >= max_attempts
        ):
          raise e
        time.sleep(current_backoff)
        current_backoff *= backoff_multiplier

  return wrapper


class GoogleAuth(httpx.Auth):
  """Custom httpx Auth class for Google Cloud Application Default Credentials."""

  def __init__(self, credentials: google.auth.credentials.Credentials):
    self._credentials = credentials

  def auth_flow(
      self, request: httpx.Request
  ) -> Generator[httpx.Request, httpx.Response, None]:
    if not self._credentials.valid:
      self._credentials.refresh(google.auth.transport.requests.Request())
    request.headers['Authorization'] = f'Bearer {self._credentials.token}'
    yield request


def create_http_client(
    *,
    vertex_ai_url: str,
    model_version: str | None = None,
    timeout: float | None = None,
    service_account: str | None = None,
    token: str | None = None,
) -> HttpDnaClient:
  """Creates a model client that connects to a Vertex AI endpoint."""
  headers = {
      'content-type': 'application/json',
  }

  credentials = None
  if token:
    headers['Authorization'] = f'Bearer {token}'
    http_client = httpx.Client(headers=headers, timeout=timeout)
  else:
    scopes = [
        'https://www.googleapis.com/auth/cloud-platform',
        'https://www.googleapis.com/auth/cloud-platform.read-only',
    ]
    source_credentials, _ = google.auth.default(scopes=scopes)

    if service_account:
      credentials = impersonated_credentials.Credentials(
          source_credentials=source_credentials,
          target_principal=service_account,
          target_scopes=scopes,
      )
    else:
      credentials = source_credentials

    http_client = httpx.Client(
        auth=GoogleAuth(credentials),
        headers=headers,
        timeout=timeout,
    )

  return HttpDnaClient(
      http_client=http_client,
      model_version=model_version,
      vertex_ai_url=vertex_ai_url,
      credentials=credentials,
  )
