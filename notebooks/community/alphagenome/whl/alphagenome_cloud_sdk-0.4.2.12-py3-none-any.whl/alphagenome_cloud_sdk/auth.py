# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Authentication utilities for AlphaGenome Cloud SDK."""

import google.auth
from google.auth import impersonated_credentials
import google.auth.credentials
import google.auth.transport.requests
import grpc

_DEFAULT_SCOPES = [
    'https://www.googleapis.com/auth/cloud-platform',
]


class GoogleAuthMetadataPlugin(grpc.AuthMetadataPlugin):
  """gRPC AuthMetadataPlugin that injects Google Cloud OAuth2 tokens into metadata."""

  def __init__(
      self,
      credentials: google.auth.credentials.Credentials | None = None,
      service_account: str | None = None,
      token: str | None = None,
  ):
    self._static_token = token
    self._request = google.auth.transport.requests.Request()

    if self._static_token is not None:
      self._credentials = None
    elif credentials is not None:
      self._credentials = credentials
    elif service_account:
      base_credentials, _ = google.auth.default(scopes=_DEFAULT_SCOPES)
      self._credentials = impersonated_credentials.Credentials(
          source_credentials=base_credentials,
          target_principal=service_account,
          target_scopes=_DEFAULT_SCOPES,
      )
    else:
      self._credentials, _ = google.auth.default(scopes=_DEFAULT_SCOPES)

  def get_token(self) -> str:
    """Returns a valid access token, refreshing if necessary."""
    if self._static_token is not None:
      return self._static_token
    if self._credentials is None:
      raise RuntimeError(
          'Credentials must be set when no static token is provided.'
      )
    if not self._credentials.valid:
      self._credentials.refresh(self._request)
    return str(self._credentials.token)

  def __call__(
      self,
      context: grpc.AuthMetadataContext,
      callback: grpc.AuthMetadataPluginCallback,
  ) -> None:
    try:
      token = self.get_token()
      callback([('authorization', f'Bearer {token}')], None)
    except Exception as exc:  # pylint: disable=broad-exception-caught
      callback(None, exc)
