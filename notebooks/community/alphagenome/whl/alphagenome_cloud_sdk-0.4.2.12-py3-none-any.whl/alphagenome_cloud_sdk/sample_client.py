# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Sample client for AlphaGenome gRPC serving on Vertex AI or local container."""

from collections.abc import Sequence
import typing

from absl import app
from absl import flags
from absl import logging
from alphagenome.data import genome

if typing.TYPE_CHECKING:
  from alphagenome.models.v1 import dna_client as dna_client_lib  # pylint: disable=g-import-not-at-top
  from alphagenome.models.v1 import dna_model  # pylint: disable=g-import-not-at-top
  from alphagenome.models.v1 import dna_output  # pylint: disable=g-import-not-at-top
  from google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top
else:
  try:
    from alphagenome.models.v1 import dna_client as dna_client_lib  # pylint: disable=g-import-not-at-top
    from alphagenome.models.v1 import dna_model  # pylint: disable=g-import-not-at-top
    from alphagenome.models.v1 import dna_output  # pylint: disable=g-import-not-at-top
  except ImportError:
    from alphagenome.models import dna_client as dna_client_lib  # pylint: disable=g-import-not-at-top
    from alphagenome.models import dna_model  # pylint: disable=g-import-not-at-top
    from alphagenome.models import dna_output  # pylint: disable=g-import-not-at-top

  try:
    from google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top
  except ImportError:
    from alphagenome_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top

_ENDPOINT = flags.DEFINE_string(
    'endpoint',
    'localhost:8081',
    'gRPC server address (e.g. localhost:8081, Vertex AI dedicated DNS'
    ' <endpoint-id>.<region>-<project-num>.prediction.vertexai.goog:443, or'
    ' standard resource name'
    ' projects/<project>/locations/<region>/endpoints/<endpoint-id>).',
)
_INSECURE = flags.DEFINE_bool(
    'insecure',
    False,
    'Use an insecure gRPC channel (for local Docker container testing).',
)
_SERVICE_ACCOUNT = flags.DEFINE_string(
    'service_account',
    None,
    'Optional service account email to impersonate.',
)
_TOKEN = flags.DEFINE_string(
    'token',
    None,
    'Optional explicit OAuth2 Bearer token.',
)
_CHROMOSOME = flags.DEFINE_string(
    'chromosome',
    'chr1',
    'Chromosome for test interval.',
)
_START = flags.DEFINE_integer(
    'start',
    1000000,
    '0-based start position for test interval.',
)
_LENGTH = flags.DEFINE_integer(
    'length',
    dna_client_lib.SEQUENCE_LENGTH_16KB,
    'Interval length (16384, 131072, 524288, or 1048576).',
)


def main(argv: Sequence[str]) -> None:
  if len(argv) > 1:
    raise app.UsageError('Too many command-line arguments.')

  logging.info(
      'Connecting to AlphaGenome gRPC endpoint: %s (insecure=%s)',
      _ENDPOINT.value,
      _INSECURE.value,
  )

  if _INSECURE.value:
    dna_client = dna_client_grpc.GrpcDnaClient.create_local_client(
        address=_ENDPOINT.value,
    )
  else:
    dna_client = dna_client_grpc.GrpcDnaClient.create_vertex_client(
        endpoint=_ENDPOINT.value,
        service_account=_SERVICE_ACCOUNT.value,
        token=_TOKEN.value,
    )

  interval = genome.Interval(
      chromosome=_CHROMOSOME.value,
      start=_START.value,
      end=_START.value + _LENGTH.value,
  )
  logging.info('Running predict_interval for %s...', interval)

  output = dna_client.predict_interval(
      interval=interval,
      organism=dna_model.Organism.HOMO_SAPIENS,
      requested_outputs=[
          dna_output.OutputType.ATAC,
          dna_output.OutputType.RNA_SEQ,
      ],
      ontology_terms=['UBERON:0001114'],
  )

  if output.atac is not None:
    logging.info(
        'ATAC prediction shape: %s, tracks: %d',
        output.atac.values.shape,
        len(output.atac.metadata),
    )
  if output.rna_seq is not None:
    logging.info(
        'RNA_SEQ prediction shape: %s, tracks: %d',
        output.rna_seq.values.shape,
        len(output.rna_seq.metadata),
    )


if __name__ == '__main__':
  app.run(main)
