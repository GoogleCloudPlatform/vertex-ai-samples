# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""gRPC client factory for AlphaGenome on Vertex AI and local containers."""

from collections.abc import Sequence
import re
import typing
from typing import Any

import google.auth.credentials
import grpc

if typing.TYPE_CHECKING:
  from alphagenome.models.v1 import dna_client  # pylint: disable=g-import-not-at-top
  from google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk import auth  # pylint: disable=g-import-not-at-top
  from google3.google.cloud.aiplatform.v1 import prediction_service_pb2  # pylint: disable=g-import-not-at-top

  _StreamDirectRawPredictRequest = (
      prediction_service_pb2.StreamDirectRawPredictRequest
  )
  _StreamDirectRawPredictResponse = (
      prediction_service_pb2.StreamDirectRawPredictResponse
  )
else:
  try:
    from alphagenome.models.v1 import dna_client  # pylint: disable=g-import-not-at-top
  except ImportError:
    from alphagenome.models import dna_client  # pylint: disable=g-import-not-at-top

  try:
    from google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk import auth  # pylint: disable=g-import-not-at-top
  except ImportError:
    from alphagenome_cloud_sdk import auth  # pylint: disable=g-import-not-at-top

  try:
    from google3.google.cloud.aiplatform.v1 import prediction_service_pb2  # pylint: disable=g-import-not-at-top

    _StreamDirectRawPredictRequest = (
        prediction_service_pb2.StreamDirectRawPredictRequest
    )
    _StreamDirectRawPredictResponse = (
        prediction_service_pb2.StreamDirectRawPredictResponse
    )
  except ImportError:
    from google.cloud.aiplatform_v1.types import prediction_service as _prediction_service  # pylint: disable=g-import-not-at-top

    _StreamDirectRawPredictRequest = (
        _prediction_service.StreamDirectRawPredictRequest.pb()
    )
    _StreamDirectRawPredictResponse = (
        _prediction_service.StreamDirectRawPredictResponse.pb()
    )


# Allow unlimited gRPC payload sizes (-1) to accommodate multi-megabyte
# multi-modal genome track predictions (1MB sequence with all tracks can
# exceed 50MB+).
MAX_MESSAGE_LENGTH = -1

DEFAULT_CHANNEL_OPTIONS: tuple[tuple[str, Any], ...] = (
    ('grpc.max_send_message_length', MAX_MESSAGE_LENGTH),
    ('grpc.max_receive_message_length', MAX_MESSAGE_LENGTH),
    ('grpc.keepalive_time_ms', 30000),
    ('grpc.keepalive_timeout_ms', 10000),
    ('grpc.keepalive_permit_without_calls', 1),
    ('grpc.http2.max_pings_without_data', 0),
)

DEFAULT_TIMEOUT = 600.0

_VERTEX_ENDPOINT_PATTERN = re.compile(
    r'^projects/([^/]+)/locations/([^/]+)/endpoints/([^/]+)$'
)


class _StreamCallWrapper:
  """Wraps a StreamDirectRawPredict call iterator and deserializes outputs."""

  def __init__(self, underlying_call: Any, response_deserializer: Any):
    self._call = underlying_call
    self._iter = iter(underlying_call)
    self._deserializer = response_deserializer

  def __iter__(self):
    return self

  def __next__(self):
    resp = next(self._iter)
    if self._deserializer is not None:
      return self._deserializer(resp.output)
    return resp.output

  def cancel(self):
    return self._call.cancel()

  def is_active(self):
    return self._call.is_active()

  def time_remaining(self):
    return self._call.time_remaining()

  def add_callback(self, callback):
    return self._call.add_callback(callback)

  def initial_metadata(self):
    return self._call.initial_metadata()

  def trailing_metadata(self):
    return self._call.trailing_metadata()

  def code(self):
    return self._call.code()

  def details(self):
    return self._call.details()


class VertexAiPredictionChannel(grpc.Channel):
  """gRPC Channel wrapper for standard Vertex AI Endpoints.

  Translates DnaModelService streaming gRPC calls into Vertex AI
  PredictionService.StreamDirectRawPredict bidirectional streaming calls.
  """

  def __init__(self, channel: grpc.Channel, endpoint: str):
    self._channel = channel
    self._endpoint = endpoint
    self._stream_direct_raw_predict = self._channel.stream_stream(
        '/google.cloud.aiplatform.v1.PredictionService/StreamDirectRawPredict',
        request_serializer=(
            _StreamDirectRawPredictRequest.SerializeToString
        ),
        response_deserializer=(
            _StreamDirectRawPredictResponse.FromString
        ),
    )

  def _merge_metadata(self, metadata: Any) -> list[tuple[str, str]]:
    meta = list(metadata) if metadata else []
    meta.append(('x-goog-request-params', f'endpoint={self._endpoint}'))
    return meta

  def stream_stream(
      self,
      method: str,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      _registered_method: Any = False,  # pylint: disable=invalid-name
  ) -> grpc.StreamStreamMultiCallable:
    del _registered_method
    channel_self = self
    endpoint_str = self._endpoint

    class _MultiCallable(grpc.StreamStreamMultiCallable):
      """StreamStreamMultiCallable adapter."""

      def __call__(
          self,
          request_iterator: Any,
          timeout: float | None = None,
          metadata: Any = None,
          credentials: grpc.CallCredentials | None = None,
          wait_for_ready: bool | None = None,
          compression: grpc.Compression | None = None,
      ):
        def _req_gen():
          for req in request_iterator:
            payload = request_serializer(req) if request_serializer else req
            yield _StreamDirectRawPredictRequest(
                endpoint=endpoint_str,
                method_name=method,
                input=payload,
            )

        call = channel_self._stream_direct_raw_predict(  # pylint: disable=protected-access
            _req_gen(),
            timeout=timeout,
            metadata=channel_self._merge_metadata(metadata),  # pylint: disable=protected-access
            credentials=credentials,
            wait_for_ready=wait_for_ready,
            compression=compression,
        )
        return _StreamCallWrapper(call, response_deserializer)

    return _MultiCallable()

  def unary_stream(
      self,
      method: str,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      _registered_method: Any = False,  # pylint: disable=invalid-name
  ) -> grpc.UnaryStreamMultiCallable:
    del _registered_method
    channel_self = self
    endpoint_str = self._endpoint

    class _MultiCallable(grpc.UnaryStreamMultiCallable):
      """UnaryStreamMultiCallable adapter."""

      def __call__(
          self,
          request: Any,
          timeout: float | None = None,
          metadata: Any = None,
          credentials: grpc.CallCredentials | None = None,
          wait_for_ready: bool | None = None,
          compression: grpc.Compression | None = None,
      ):
        def _req_gen():
          payload = (
              request_serializer(request) if request_serializer else request
          )
          yield _StreamDirectRawPredictRequest(
              endpoint=endpoint_str,
              method_name=method,
              input=payload,
          )

        call = channel_self._stream_direct_raw_predict(  # pylint: disable=protected-access
            _req_gen(),
            timeout=timeout,
            metadata=channel_self._merge_metadata(metadata),  # pylint: disable=protected-access
            credentials=credentials,
            wait_for_ready=wait_for_ready,
            compression=compression,
        )
        return _StreamCallWrapper(call, response_deserializer)

    return _MultiCallable()

  def unary_unary(self, *args, **kwargs):
    return self._channel.unary_unary(*args, **kwargs)

  def stream_unary(self, *args, **kwargs):
    return self._channel.stream_unary(*args, **kwargs)

  def subscribe(self, callback, try_to_connect=False):
    return self._channel.subscribe(callback, try_to_connect=try_to_connect)

  def unsubscribe(self, callback):
    return self._channel.unsubscribe(callback)

  def close(self):
    return self._channel.close()

  def __enter__(self):
    return self

  def __exit__(self, exc_type, exc_val, exc_tb):
    self.close()
    return False


def _resolve_model_version(
    model_version: dna_client.ModelVersion | str | None,
) -> dna_client.ModelVersion | None:
  """Validates and converts model_version to a dna_client.ModelVersion enum."""
  if model_version is None or isinstance(
      model_version, dna_client.ModelVersion
  ):
    return model_version
  if isinstance(model_version, str):
    try:
      return dna_client.ModelVersion[model_version]
    except KeyError as e:
      valid_versions = [v.name for v in dna_client.ModelVersion]
      raise ValueError(
          f'Invalid model_version {model_version!r}. Must be one of'
          f' {valid_versions} or a dna_client.ModelVersion enum.'
      ) from e
  raise ValueError(f'Unsupported model_version type: {type(model_version)!r}.')


class GrpcDnaClient(dna_client.DnaClient):
  """AlphaGenome gRPC DnaClient for Vertex AI and local containers."""

  def __init__(
      self,
      *,
      channel: grpc.Channel,
      model_version: dna_client.ModelVersion | str | None = None,
  ):
    resolved_model_version = _resolve_model_version(model_version)
    super().__init__(
        channel=channel,
        model_version=resolved_model_version,
    )

  @classmethod
  def create_vertex_client(
      cls,
      endpoint: str,
      *,
      credentials: google.auth.credentials.Credentials | None = None,
      service_account: str | None = None,
      token: str | None = None,
      model_version: dna_client.ModelVersion | str | None = None,
      timeout: float = DEFAULT_TIMEOUT,
      channel_options: Sequence[tuple[str, Any]] | None = None,
  ) -> 'GrpcDnaClient':
    """Creates an authenticated gRPC client for a Vertex AI endpoint.

    Supports two Vertex AI Endpoint formats:
    1. Dedicated Endpoint DNS:
       `"<endpoint-id>.<region>-<project-num>.prediction.vertexai.goog:443"`
       Connects directly via native DnaModelService gRPC over TLS.
    2. Standard Endpoint Resource Name:
       `"projects/<project>/locations/<region>/endpoints/<endpoint-id>"`
       Connects to `<region>-aiplatform.googleapis.com:443` and wraps
       requests in `PredictionService.StreamDirectRawPredict`.

    Args:
      endpoint: Vertex AI endpoint DNS address or resource name.
      credentials: Optional explicit Google Auth credentials.
      service_account: Optional service account email to impersonate.
      token: Optional static OAuth2 access token.
      model_version: Optional AlphaGenome model version (ModelVersion enum or
        enum name).
      timeout: Timeout in seconds to wait for the channel to be ready.
      channel_options: Optional additional gRPC channel options.

    Returns:
      An initialized `GrpcDnaClient` ready for inference.
    """
    resolved_model_version = _resolve_model_version(model_version)
    auth_plugin = auth.GoogleAuthMetadataPlugin(
        credentials=credentials,
        service_account=service_account,
        token=token,
    )
    call_creds = grpc.metadata_call_credentials(auth_plugin)
    ssl_creds = grpc.ssl_channel_credentials()
    composite_creds = grpc.composite_channel_credentials(ssl_creds, call_creds)

    options = list(DEFAULT_CHANNEL_OPTIONS)
    if channel_options:
      options.extend(channel_options)

    match = _VERTEX_ENDPOINT_PATTERN.match(endpoint)
    if match:
      location = match.group(2)
      api_host = f'{location}-aiplatform.googleapis.com:443'
      raw_channel = grpc.secure_channel(
          api_host, composite_creds, options=options
      )
      grpc.channel_ready_future(raw_channel).result(timeout=timeout)
      channel = VertexAiPredictionChannel(raw_channel, endpoint)
    else:
      target = endpoint if ':' in endpoint else f'{endpoint}:443'
      channel = grpc.secure_channel(target, composite_creds, options=options)
      grpc.channel_ready_future(channel).result(timeout=timeout)

    return cls(
        channel=channel,
        model_version=resolved_model_version,
    )

  @classmethod
  def create_local_client(
      cls,
      address: str = 'localhost:8081',
      *,
      model_version: dna_client.ModelVersion | str | None = None,
      timeout: float = DEFAULT_TIMEOUT,
      channel_options: Sequence[tuple[str, Any]] | None = None,
  ) -> 'GrpcDnaClient':
    """Creates an insecure gRPC client for a local container."""
    resolved_model_version = _resolve_model_version(model_version)
    options = list(DEFAULT_CHANNEL_OPTIONS)
    if channel_options:
      options.extend(channel_options)

    channel = grpc.insecure_channel(address, options=options)
    grpc.channel_ready_future(channel).result(timeout=timeout)

    return cls(
        channel=channel,
        model_version=resolved_model_version,
    )


def create_grpc_client(
    endpoint: str,
    *,
    credentials: google.auth.credentials.Credentials | None = None,
    service_account: str | None = None,
    token: str | None = None,
    model_version: dna_client.ModelVersion | str | None = None,
    timeout: float = DEFAULT_TIMEOUT,
    channel_options: Sequence[tuple[str, Any]] | None = None,
    insecure: bool = False,
) -> GrpcDnaClient:
  """Convenience factory for creating an AlphaGenome gRPC client."""
  if insecure:
    return GrpcDnaClient.create_local_client(
        address=endpoint,
        model_version=model_version,
        timeout=timeout,
        channel_options=channel_options,
    )
  return GrpcDnaClient.create_vertex_client(
      endpoint=endpoint,
      credentials=credentials,
      service_account=service_account,
      token=token,
      model_version=model_version,
      timeout=timeout,
      channel_options=channel_options,
  )


create_vertex_client = GrpcDnaClient.create_vertex_client
create_local_client = GrpcDnaClient.create_local_client
