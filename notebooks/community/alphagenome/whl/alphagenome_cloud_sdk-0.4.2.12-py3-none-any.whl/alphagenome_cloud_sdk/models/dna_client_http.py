# Copyright 2025 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Client implementation for interacting with a DNA model server over HTTP."""

from collections.abc import Callable, Container, Generator, Iterable, Iterator, Sequence
import base64
import concurrent.futures
import dataclasses
import functools
import importlib
import json
import random
import time
import typing
from typing import Any, TypeVar
import urllib.error
import urllib.request

from alphagenome.data import genome
from alphagenome.data import ontology
import anndata
import google.auth
from google.auth import impersonated_credentials
import google.auth.credentials
import google.auth.transport.requests
from google.protobuf import json_format
from google.protobuf import message
import numpy as np
import pandas as pd
import tqdm.auto

if typing.TYPE_CHECKING:
  from alphagenome.models.v1 import dna_client  # pylint: disable=g-import-not-at-top
  from alphagenome.models.v1 import dna_model  # pylint: disable=g-import-not-at-top
  from alphagenome.models.v1 import dna_output  # pylint: disable=g-import-not-at-top
  from alphagenome.models.v1 import interval_scorers as interval_scorers_lib  # pylint: disable=g-import-not-at-top
  from alphagenome.models.v1 import variant_scorers as variant_scorers_lib  # pylint: disable=g-import-not-at-top
  from google3.google.gdm.gdmscience.alphagenome.v1main import dna_model_pb2  # pylint: disable=g-import-not-at-top
  from google3.google.gdm.gdmscience.alphagenome.v1main import dna_model_service_pb2  # pylint: disable=g-import-not-at-top
else:
  try:
    from alphagenome.models.v1 import dna_client  # pylint: disable=g-import-not-at-top
    from alphagenome.models.v1 import dna_model  # pylint: disable=g-import-not-at-top
    from alphagenome.models.v1 import dna_output  # pylint: disable=g-import-not-at-top
    from alphagenome.models.v1 import interval_scorers as interval_scorers_lib  # pylint: disable=g-import-not-at-top
    from alphagenome.models.v1 import variant_scorers as variant_scorers_lib  # pylint: disable=g-import-not-at-top
  except ImportError:
    from alphagenome.models import dna_client  # pylint: disable=g-import-not-at-top
    from alphagenome.models import dna_model  # pylint: disable=g-import-not-at-top
    from alphagenome.models import dna_output  # pylint: disable=g-import-not-at-top
    from alphagenome.models import interval_scorers as interval_scorers_lib  # pylint: disable=g-import-not-at-top
    from alphagenome.models import variant_scorers as variant_scorers_lib  # pylint: disable=g-import-not-at-top

  try:
    from google3.google.gdm.gdmscience.alphagenome.v1main import dna_model_pb2  # pylint: disable=g-import-not-at-top
    from google3.google.gdm.gdmscience.alphagenome.v1main import dna_model_service_pb2  # pylint: disable=g-import-not-at-top
  except ImportError:
    from alphagenome.protos import dna_model_pb2  # pylint: disable=g-import-not-at-top
    from alphagenome.protos import dna_model_service_pb2  # pylint: disable=g-import-not-at-top


class _FallbackNamespace:
  """Simple namespace wrapper for fallback HTTP client symbols."""

  def __init__(self, **kwargs: Any):
    for k, v in kwargs.items():
      setattr(self, k, v)


class HttpStatusError(RuntimeError):
  """Raised when the HTTP endpoint returns a non-2xx status code."""

  def __init__(
      self, message_text: str, request: Any = None, response: Any = None
  ):
    super().__init__(message_text)
    self.request = request
    self.response = response


class _FallbackHttpRequest:
  """Fallback HTTP request object matching httpx.Request interface."""

  def __init__(
      self,
      method: str,
      url: str,
      content: bytes = b'',
      headers: dict[str, str] | None = None,
  ):
    self.method = method
    self.url = url
    self.content = content
    self.headers = headers or {}


class _FallbackHttpResponse:
  """Fallback HTTP response object matching httpx.Response stream interface."""

  def __init__(
      self,
      status_code: int,
      content: bytes = b'',
      headers: dict[str, str] | None = None,
      request: Any = None,
  ):
    self.status_code = status_code
    self._content = content
    self.headers = headers or {}
    self.request = request

  def read(self) -> bytes:
    return self._content

  def raise_for_status(self) -> None:
    if self.status_code >= 400:
      raise HttpStatusError(
          f'HTTP error {self.status_code}',
          request=self.request,
          response=self,
      )

  def iter_lines(self) -> Iterator[str]:
    for line in self._content.decode('utf-8', errors='replace').splitlines():
      yield line

  def __enter__(self) -> '_FallbackHttpResponse':
    return self

  def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
    pass


class _FallbackMockTransport:
  """Fallback mock transport matching httpx.MockTransport interface."""

  def __init__(
      self, handler: Callable[[_FallbackHttpRequest], _FallbackHttpResponse]
  ):
    self.handler = handler


json_module_dumps = json.dumps


class _FallbackHttpClient:
  """Lightweight urllib/mock HTTP client matching the httpx.Client stream API."""

  def __init__(
      self,
      *,
      auth: Any = None,
      headers: dict[str, str] | None = None,
      timeout: float | None = None,
      transport: _FallbackMockTransport | None = None,
  ):
    self._auth = auth
    self.headers = dict(headers) if headers else {}
    self._headers = self.headers
    self._timeout = timeout
    self._transport = transport

  def stream(
      self, method: str, url: str, *, json: dict[str, Any]  # pylint: disable=redefined-outer-name
  ) -> _FallbackHttpResponse:
    """Streams an HTTP request and returns a response context manager."""
    content = json_module_dumps(json).encode('utf-8')
    req_headers = dict(self._headers)
    req_headers.setdefault('Content-Type', 'application/json')
    req_obj = _FallbackHttpRequest(method, url, content, req_headers)
    if self._auth is not None and hasattr(self._auth, 'apply_headers'):
      self._auth.apply_headers(req_obj.headers)
    if self._transport is not None:
      resp = self._transport.handler(req_obj)
      resp.request = req_obj
      return resp

    urllib_req = urllib.request.Request(
        url, data=content, headers=req_obj.headers, method=method
    )
    try:
      with urllib.request.urlopen(urllib_req, timeout=self._timeout) as resp:
        return _FallbackHttpResponse(
            status_code=resp.status,
            content=resp.read(),
            headers=dict(resp.headers),
            request=req_obj,
        )
    except urllib.error.HTTPError as e:
      return _FallbackHttpResponse(
          status_code=e.code,
          content=e.read(),
          headers=dict(e.headers) if e.headers else {},
          request=req_obj,
      )


def _resolve_httpx() -> Any:
  try:
    return importlib.import_module('httpx')
  except ImportError:
    return _FallbackNamespace(
        Client=_FallbackHttpClient,
        Request=_FallbackHttpRequest,
        Response=_FallbackHttpResponse,
        MockTransport=_FallbackMockTransport,
        HTTPStatusError=HttpStatusError,
        Auth=object,
    )


httpx = _resolve_httpx()

# Maximum width of an in silico mutagenesis (ISM) interval request.
MAX_ISM_INTERVAL_WIDTH = 10

# Maximum number of variant scorers per request.
MAX_VARIANT_SCORERS_PER_REQUEST = 20

_RetryableFunction = TypeVar('_RetryableFunction', bound=Callable[..., Any])


def _normalize_model_version(
    model_version: dna_client.ModelVersion | str | None,
) -> str | None:
  """Normalizes model_version enum or string to its ModelVersion enum name."""
  if model_version is None:
    return None
  if isinstance(model_version, dna_client.ModelVersion):
    return model_version.name
  if isinstance(model_version, str):
    try:
      return dna_client.ModelVersion[model_version].name
    except KeyError as e:
      valid_versions = [v.name for v in dna_client.ModelVersion]
      raise ValueError(
          f'Invalid model_version {model_version!r}. Must be one of'
          f' {valid_versions} or a dna_client.ModelVersion enum.'
      ) from e
  raise ValueError(f'Unsupported model_version type: {type(model_version)!r}.')


def _format_ontology_terms_for_json(
    ontology_terms: Iterable[ontology.OntologyTerm | str] | None,
) -> list[dict[str, str]] | None:
  """Formats ontology terms into the JSON structure expected by the endpoint."""
  if ontology_terms is None:
    return None

  formatted_terms = []
  for term in dict.fromkeys(
      ontology_terms
  ):  # Use dict.fromkeys to ensure uniqueness
    if isinstance(term, ontology.OntologyTerm):
      formatted_terms.append(
          {'ontology_type': f'ONTOLOGY_TYPE_{term.type.name}', 'id': term.id}
      )
    else:  # Assume it's a CURIE string
      ont_term_obj = ontology.from_curie(term)
      formatted_terms.append({
          'ontology_type': f'ONTOLOGY_TYPE_{ont_term_obj.type.name}',
          'id': ont_term_obj.id,
      })
  return formatted_terms


def _format_variant_scorers_for_json(
    variant_scorers: Sequence[variant_scorers_lib.VariantScorerTypes],
) -> list[dict[str, dict[str, str | int]]]:
  """Formats variant scorers into the JSON structure expected by the endpoint."""
  formatted_scorers = []
  for scorer in variant_scorers:
    if isinstance(scorer, variant_scorers_lib.CenterMaskScorer):
      payload: dict[str, str | int] = {
          'aggregationType': f'AGGREGATION_TYPE_{scorer.aggregation_type.name}',
          'requestedOutput': f'OUTPUT_TYPE_{scorer.requested_output.name}',
      }
      if scorer.width is not None:
        payload['width'] = str(scorer.width)
      formatted_scorers.append({'centerMask': payload})
    elif isinstance(scorer, variant_scorers_lib.GeneMaskLFCScorer):
      formatted_scorers.append({
          'geneMask': {
              'requestedOutput': f'OUTPUT_TYPE_{scorer.requested_output.name}',
          }
      })
    elif isinstance(scorer, variant_scorers_lib.GeneMaskActiveScorer):
      formatted_scorers.append({
          'geneMaskActive': {
              'requestedOutput': f'OUTPUT_TYPE_{scorer.requested_output.name}',
          }
      })
    elif isinstance(scorer, variant_scorers_lib.GeneMaskSplicingScorer):
      payload = {
          'requestedOutput': f'OUTPUT_TYPE_{scorer.requested_output.name}',
      }
      if scorer.width is not None:
        payload['width'] = str(scorer.width)
      formatted_scorers.append({'geneMaskSplicing': payload})
    elif isinstance(scorer, variant_scorers_lib.PolyadenylationScorer):
      formatted_scorers.append({'paQtl': {}})
    elif isinstance(scorer, variant_scorers_lib.SpliceJunctionScorer):
      formatted_scorers.append({'spliceJunction': {}})
    elif isinstance(scorer, variant_scorers_lib.ContactMapScorer):
      formatted_scorers.append({'contactMap': {}})
    else:
      raise ValueError(f'Unsupported variant scorer type: {type(scorer)}')
  return formatted_scorers


def _format_interval_scorers_for_json(
    interval_scorers: Sequence[interval_scorers_lib.IntervalScorerTypes],
) -> list[dict[str, dict[str, str]]]:
  """Formats interval scorers into the JSON structure expected by the endpoint."""
  formatted_scorers = []
  for scorer in interval_scorers:
    if isinstance(scorer, interval_scorers_lib.GeneMaskScorer):
      payload = {
          'requestedOutput': f'OUTPUT_TYPE_{scorer.requested_output.name}',
          'aggregationType': (
              f'INTERVAL_AGGREGATION_TYPE_{scorer.aggregation_type.name}'
          ),
      }
      if scorer.width is not None:
        payload['width'] = str(scorer.width)
      formatted_scorers.append({'geneMask': payload})
    else:
      raise ValueError(f'Unsupported interval scorer type: {type(scorer)}')
  return formatted_scorers


# Supported DNA sequence lengths.
SEQUENCE_LENGTH_16KB = 2**14  # 16_384
SEQUENCE_LENGTH_100KB = 2**17  # 131_072
SEQUENCE_LENGTH_500KB = 2**19  # 524_288
SEQUENCE_LENGTH_1MB = 2**20  # 1_048_576

SUPPORTED_SEQUENCE_LENGTHS = {
    'SEQUENCE_LENGTH_16KB': SEQUENCE_LENGTH_16KB,
    'SEQUENCE_LENGTH_100KB': SEQUENCE_LENGTH_100KB,
    'SEQUENCE_LENGTH_500KB': SEQUENCE_LENGTH_500KB,
    'SEQUENCE_LENGTH_1MB': SEQUENCE_LENGTH_1MB,
}


def validate_sequence_length(length: int):
  """Validate that the input sequence length is supported by the model."""
  if length not in SUPPORTED_SEQUENCE_LENGTHS.values():
    raise ValueError(
        f'Sequence length {length} not supported by the model.'
        f' Supported lengths: {[*SUPPORTED_SEQUENCE_LENGTHS.values()]}'
    )


def _fix_metadata_for_negative_strand(metadata: pd.DataFrame) -> pd.DataFrame:
  """Fixes metadata for negative strand by swapping +/- pairs."""
  df_strands = pd.DataFrame({
      'name': metadata['name'].values,
      'strand': metadata['strand'].values,
      'old_idx': np.arange(len(metadata)),
  })
  df_strands = df_strands[df_strands.strand != genome.STRAND_UNSTRANDED]
  df_strands.sort_values(['strand', 'name'], inplace=True)

  if np.any(df_strands.groupby('name').size() != 2):
    raise ValueError('Not all stranded tracks have both + and - strand.')
  if (df_strands.strand == genome.STRAND_POSITIVE).sum() != (
      df_strands.strand == genome.STRAND_NEGATIVE
  ).sum():
    raise ValueError(
        'We need to have the exact same number of + and - stranded tracks'
    )
  new_idx = df_strands.old_idx.values.reshape((2, -1))[::-1].ravel()
  idx = np.arange(len(metadata))
  idx[df_strands.old_idx.values] = new_idx

  return metadata.iloc[idx]


class HttpDnaClient(dna_model.DnaModel):
  """Client for interacting with a DNA model server over HTTP."""

  def __init__(
      self,
      *,
      http_client: Any,
      model_version: dna_client.ModelVersion | str | None = None,
      vertex_ai_url: str,
      credentials: google.auth.credentials.Credentials | None = None,
      use_static_token: bool = False,
  ):
    self._http_client = http_client
    self._model_version = _normalize_model_version(model_version)
    self._vertex_ai_url = vertex_ai_url
    self._credentials = credentials
    self._use_static_token = use_static_token

  def _has_static_auth_header(self) -> bool:
    headers = getattr(self._http_client, 'headers', None)
    if not headers:
      return False
    return any(k.lower() == 'authorization' for k in headers.keys())

  def _authenticate(self):
    """Authenticate and get OAuth2 token."""
    if self._use_static_token or self._has_static_auth_header():
      return
    if self._credentials is None:
      self._credentials, _ = google.auth.default(
          scopes=[
              'https://www.googleapis.com/auth/cloud-platform',
              'https://www.googleapis.com/auth/cloud-platform.read-only',
          ]
      )
    if not self._credentials.valid:
      self._credentials.refresh(google.auth.transport.requests.Request())

  def validate_credentials(self):
    if self._use_static_token or self._has_static_auth_header():
      return 'Credentials are valid.'
    if not self._credentials or not self._credentials.valid:
      self._authenticate()
    else:
      return 'Credentials are valid.'

  def _iter_response_protos(
      self,
      response: Any,
      proto_cls: type[message.Message],
  ) -> Iterator[Any]:
    """Iterates over NDJSON response lines and yields parsed protobuf messages."""
    for raw_line in response.iter_lines():
      if not raw_line:
        continue
      line = raw_line.strip()
      if not line:
        continue
      payload = json.loads(line)
      if isinstance(payload, dict) and 'proto_b64' in payload:
        yield proto_cls.FromString(base64.b64decode(payload['proto_b64']))
      else:
        yield json_format.ParseDict(payload, proto_cls())

  def predict_interval(
      self,
      interval: genome.Interval,
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
      requested_outputs: Iterable[dna_output.OutputType] | None = None,
      ontology_terms: Iterable[ontology.OntologyTerm | str] | None = None,
  ) -> dna_output.Output:
    self._authenticate()
    strand_map = {
        '+': 'STRAND_POSITIVE',
        '-': 'STRAND_NEGATIVE',
        '.': 'STRAND_UNSTRANDED',
    }
    outputs_list = (
        [f'OUTPUT_TYPE_{o.name}' for o in requested_outputs]
        if requested_outputs is not None
        else []
    )
    request_body: dict[str, Any] = {
        'instances': [{
            'request_type': 'predict_interval',
            'data': {
                'interval': {
                    'chromosome': interval.chromosome,
                    'start': str(interval.start),
                    'end': str(interval.end),
                    'strand': strand_map.get(
                        str(interval.strand), 'STRAND_UNSTRANDED'
                    ),
                },
                'organism': f'ORGANISM_{organism.name}',
                'requestedOutputs': outputs_list,
            },
        }]
    }
    formatted_ontology_terms = _format_ontology_terms_for_json(ontology_terms)
    if formatted_ontology_terms:
      request_body['instances'][0]['data'][
          'ontology_terms'
      ] = formatted_ontology_terms
    if self._model_version:
      request_body['instances'][0]['data']['modelVersion'] = self._model_version

    with self._http_client.stream(
        'POST',
        self._vertex_ai_url,
        json=request_body,
    ) as response:
      response.raise_for_status()
      response_protos = self._iter_response_protos(
          response, dna_model_service_pb2.PredictIntervalResponse
      )
      return dna_client._make_output(response_protos, interval=interval)  # pylint: disable=protected-access

  def predict_variant(
      self,
      interval: genome.Interval,
      variant: genome.Variant,
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
      requested_outputs: Iterable[dna_output.OutputType] | None = None,
      ontology_terms: Iterable[ontology.OntologyTerm | str] | None = None,
      fix_negative_strand: bool = False,
  ) -> dna_output.VariantOutput:
    validate_sequence_length(interval.width)
    self._authenticate()
    strand_map = {
        '+': 'STRAND_POSITIVE',
        '-': 'STRAND_NEGATIVE',
        '.': 'STRAND_UNSTRANDED',
    }

    if fix_negative_strand and interval.negative_strand:
      variant = variant.copy()
      variant.position = (
          interval.end
          - variant.position
          - len(variant.reference_bases)
          + 2
          + interval.start
      )

    outputs_list = (
        [f'OUTPUT_TYPE_{o.name}' for o in requested_outputs]
        if requested_outputs is not None
        else []
    )
    request_body: dict[str, Any] = {
        'instances': [{
            'request_type': 'predict_variant',
            'data': {
                'interval': {
                    'chromosome': interval.chromosome,
                    'start': str(interval.start),
                    'end': str(interval.end),
                    'strand': strand_map.get(
                        str(interval.strand), 'STRAND_UNSTRANDED'
                    ),
                },
                'variant': {
                    'chromosome': variant.chromosome,
                    'position': str(variant.position),
                    'referenceBases': variant.reference_bases,
                    'alternateBases': variant.alternate_bases,
                },
                'organism': f'ORGANISM_{organism.name}',
                'requested_outputs': outputs_list,
            },
        }]
    }
    formatted_ontology_terms = _format_ontology_terms_for_json(ontology_terms)
    if formatted_ontology_terms:
      request_body['instances'][0]['data'][
          'ontology_terms'
      ] = formatted_ontology_terms
    if self._model_version:
      request_body['instances'][0]['data']['modelVersion'] = self._model_version

    with self._http_client.stream(
        'POST',
        self._vertex_ai_url,
        json=request_body,
    ) as response:
      response.raise_for_status()
      response_protos = self._iter_response_protos(
          response, dna_model_service_pb2.PredictVariantResponse
      )
      variant_output = dna_client._make_variant_output(response_protos)  # pylint: disable=protected-access

      if fix_negative_strand and interval.negative_strand:
        variant_output = dna_output.VariantOutput(
            reference=variant_output.reference.map_track_data(
                lambda tdata, _: dataclasses.replace(
                    tdata,
                    metadata=_fix_metadata_for_negative_strand(tdata.metadata),
                )
            ),
            alternate=variant_output.alternate.map_track_data(
                lambda tdata, _: dataclasses.replace(
                    tdata,
                    metadata=_fix_metadata_for_negative_strand(tdata.metadata),
                )
            ),
        )
      return variant_output

  def output_metadata(
      self, organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS
  ) -> dna_output.OutputMetadata:
    """Get the metadata for a given organism.

    Args:
      organism: Organism to get metadata for.

    Returns:
      OutputMetadata for the provided organism.
    """
    self._authenticate()
    request_body: dict[str, Any] = {
        'instances': [{
            'request_type': 'get_metadata',
            'data': {
                'organism': f'ORGANISM_{organism.name}',
            },
        }]
    }

    with self._http_client.stream(
        'POST',
        self._vertex_ai_url,
        json=request_body,
    ) as response:
      response.raise_for_status()
      response_protos = self._iter_response_protos(
          response, dna_model_service_pb2.MetadataResponse
      )
      return dna_client.construct_output_metadata(response_protos)

  def predict_sequence(
      self,
      sequence: str,
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
      requested_outputs: Iterable[dna_output.OutputType],
      ontology_terms: Iterable[ontology.OntologyTerm | str] | None = None,
      interval: genome.Interval | None = None,
  ) -> dna_output.Output:
    self._authenticate()
    valid_sequence_characters = frozenset('ACGTN')
    if not (unique_values := set(sequence)).issubset(valid_sequence_characters):
      invalid_characters = ','.join(unique_values - valid_sequence_characters)
      raise ValueError(
          'Invalid sequence, must only contain the characters "ACGTN". Found'
          f' invalid characters: "{invalid_characters}"'
      )
    validate_sequence_length(len(sequence))

    request_body: dict[str, Any] = {
        'instances': [{
            'request_type': 'predict_sequence',
            'data': {
                'sequence': sequence,
                'organism': f'ORGANISM_{organism.name}',
                'requestedOutputs': [
                    f'OUTPUT_TYPE_{o.name}' for o in requested_outputs
                ],
            },
        }]
    }

    formatted_ontology_terms = _format_ontology_terms_for_json(ontology_terms)
    if formatted_ontology_terms:
      request_body['instances'][0]['data'][
          'ontology_terms'
      ] = formatted_ontology_terms
    if self._model_version:
      request_body['instances'][0]['data']['modelVersion'] = self._model_version

    with self._http_client.stream(
        'POST',
        self._vertex_ai_url,
        json=request_body,
    ) as response:
      response.raise_for_status()
      response_protos = self._iter_response_protos(
          response, dna_model_service_pb2.PredictSequenceResponse
      )
      return dna_client._make_output(response_protos, interval=interval)  # pylint: disable=protected-access

  def score_interval(
      self,
      interval: genome.Interval,
      interval_scorers: Sequence[interval_scorers_lib.IntervalScorerTypes] = (),
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
      merge_stranded_gene_tracks: bool = True,
  ) -> list[anndata.AnnData]:
    self._authenticate()
    if not interval_scorers:
      interval_scorers = list(
          interval_scorers_lib.RECOMMENDED_INTERVAL_SCORERS.values()
      )

    validate_sequence_length(interval.width)
    if len(interval_scorers) != len(set(interval_scorers)):
      raise ValueError(
          f'Duplicate interval scorers requested: {interval_scorers}.'
      )
    if len(interval_scorers) > MAX_VARIANT_SCORERS_PER_REQUEST:
      raise ValueError(
          'Too many interval scorers requested, '
          f'maximum allowed: {MAX_VARIANT_SCORERS_PER_REQUEST}.'
      )
    if any(
        scorer.width is not None and scorer.width > interval.width
        for scorer in interval_scorers
    ):
      raise ValueError('Interval scorers must have widths <= interval width.')

    strand_map = {
        '+': 'STRAND_POSITIVE',
        '-': 'STRAND_NEGATIVE',
        '.': 'STRAND_UNSTRANDED',
    }
    request_body: dict[str, Any] = {
        'instances': [{
            'request_type': 'score_interval',
            'data': {
                'interval': {
                    'chromosome': interval.chromosome,
                    'start': str(interval.start),
                    'end': str(interval.end),
                    'strand': strand_map.get(
                        str(interval.strand), 'STRAND_UNSTRANDED'
                    ),
                },
                'organism': f'ORGANISM_{organism.name}',
                'intervalScorers': _format_interval_scorers_for_json(
                    interval_scorers
                ),
                'mergeStrandedGeneTracks': merge_stranded_gene_tracks,
            },
        }]
    }

    if self._model_version:
      request_body['instances'][0]['data']['modelVersion'] = self._model_version

    with self._http_client.stream(
        'POST',
        self._vertex_ai_url,
        json=request_body,
    ) as response:
      response.raise_for_status()
      response_protos = self._iter_response_protos(
          response, dna_model_service_pb2.ScoreIntervalResponse
      )
      interval_outputs = dna_client._make_interval_output(  # pylint: disable=protected-access
          response_protos, interval
      )
      for ix in range(len(interval_scorers)):
        interval_outputs[ix].uns['interval_scorer'] = interval_scorers[ix]
      return interval_outputs

  def score_variant(
      self,
      interval: genome.Interval,
      variant: genome.Variant,
      variant_scorers: Sequence[variant_scorers_lib.VariantScorerTypes] = (),
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
      fix_negative_strand: bool = False,
      merge_stranded_gene_tracks: bool = True,
  ) -> list[anndata.AnnData]:
    self._authenticate()
    if not variant_scorers:
      variant_scorers = variant_scorers_lib.get_recommended_scorers(
          organism.to_proto()
      )

    validate_sequence_length(interval.width)
    for variant_scorer in variant_scorers:
      supported_organisms = variant_scorers_lib.SUPPORTED_ORGANISMS[
          variant_scorer.base_variant_scorer
      ]
      if organism.to_proto() not in supported_organisms:
        supported_organisms = [
            dna_model_pb2.Organism.Name(o).removeprefix('ORGANISM_')
            for o in supported_organisms
        ]
        raise ValueError(
            f'Unsupported organism: {organism.name} for scorer'
            f' {variant_scorer}. Supported organisms:'
            f' {supported_organisms}'
        )
    if len(variant_scorers) != len(set(variant_scorers)):
      raise ValueError(
          f'Duplicate variant scorers requested: {variant_scorers}.'
      )
    if len(variant_scorers) > MAX_VARIANT_SCORERS_PER_REQUEST:
      raise ValueError(
          'Too many variant scorers requested, '
          f'maximum allowed: {MAX_VARIANT_SCORERS_PER_REQUEST}.'
      )

    strand_map = {
        '+': 'STRAND_POSITIVE',
        '-': 'STRAND_NEGATIVE',
        '.': 'STRAND_UNSTRANDED',
    }

    if fix_negative_strand and interval.negative_strand:
      variant = variant.copy()
      variant.position = (
          interval.end
          - variant.position
          - len(variant.reference_bases)
          + 2
          + interval.start
      )

    request_body: dict[str, Any] = {
        'instances': [{
            'request_type': 'score_variant',
            'data': {
                'interval': {
                    'chromosome': interval.chromosome,
                    'start': str(interval.start),
                    'end': str(interval.end),
                    'strand': strand_map.get(
                        str(interval.strand), 'STRAND_UNSTRANDED'
                    ),
                },
                'variant': {
                    'chromosome': variant.chromosome,
                    'position': str(variant.position),
                    'referenceBases': variant.reference_bases,
                    'alternateBases': variant.alternate_bases,
                },
                'organism': f'ORGANISM_{organism.name}',
                'variantScorers': _format_variant_scorers_for_json(
                    variant_scorers
                ),
                'mergeStrandedGeneTracks': merge_stranded_gene_tracks,
            },
        }]
    }

    if self._model_version:
      request_body['instances'][0]['data']['modelVersion'] = self._model_version

    with self._http_client.stream(
        'POST',
        self._vertex_ai_url,
        json=request_body,
    ) as response:
      response.raise_for_status()
      response_lines = list(
          self._iter_response_protos(
              response, dna_model_service_pb2.ScoreVariantResponse
          )
      )

      variant_outputs = dna_client._make_score_variant_output(  # pylint: disable=protected-access
          iter(response_lines), interval
      )

      if fix_negative_strand and interval.negative_strand:
        for adata in variant_outputs:
          adata.var = _fix_metadata_for_negative_strand(adata.var)

      for ix in range(len(variant_scorers)):
        variant_outputs[ix].uns['variant_scorer'] = variant_scorers[ix]
      return variant_outputs

  def score_ism_variants(
      self,
      interval: genome.Interval,
      ism_interval: genome.Interval,
      variant_scorers: Sequence[variant_scorers_lib.VariantScorerTypes] = (),
      *,
      organism: dna_model.Organism = dna_model.Organism.HOMO_SAPIENS,
      progress_bar: bool = True,
      max_workers: int = dna_model.DEFAULT_MAX_WORKERS,
      interval_variant: genome.Variant | None = None,
      merge_stranded_gene_tracks: bool = True,
  ) -> list[list[anndata.AnnData]]:
    """Generate in-silico mutagenesis (ISM) variant scores for a given interval.

    Args:
      interval: DNA interval to make the prediction for.
      ism_interval: Interval to perform ISM.
      variant_scorers: Sequence of variant scorers to use for scoring each
        variant. If no variant scorers are provided, the recommended variant
        scorers for the organism will be used.
      organism: Organism to use for the prediction.
      progress_bar: If True, show a progress bar.
      max_workers: Number of parallel workers to use.
      interval_variant: Optional variant to use as an alternate-allele
        background for the in-silico mutagenesis.
      merge_stranded_gene_tracks: If True, merges gene-centric scores from
        stranded tracks into a single, unstranded track.

    Returns:
      List of variant scores for each variant in the ISM interval.
    """
    self._authenticate()
    if not variant_scorers:
      variant_scorers = variant_scorers_lib.get_recommended_scorers(
          organism.to_proto()
      )

    validate_sequence_length(interval.width)
    if ism_interval.negative_strand:
      raise ValueError('ISM interval must be on the positive strand.')

    ism_intervals = []
    for position in range(0, ism_interval.width, MAX_ISM_INTERVAL_WIDTH):
      ism_intervals.append(
          genome.Interval(
              ism_interval.chromosome,
              ism_interval.start + position,
              min(
                  ism_interval.start + position + MAX_ISM_INTERVAL_WIDTH,
                  ism_interval.end,
              ),
          )
      )

    @retry_http
    def _score_ism_variant(
        sub_ism_interval: genome.Interval,
    ) -> list[anndata.AnnData]:
      strand_map = {
          '+': 'STRAND_POSITIVE',
          '-': 'STRAND_NEGATIVE',
          '.': 'STRAND_UNSTRANDED',
      }
      request_body: dict[str, Any] = {
          'instances': [{
              'request_type': 'score_ism_variant',
              'data': {
                  'interval': {
                      'chromosome': interval.chromosome,
                      'start': str(interval.start),
                      'end': str(interval.end),
                      'strand': strand_map.get(
                          str(interval.strand), 'STRAND_UNSTRANDED'
                      ),
                  },
                  'ismInterval': {
                      'chromosome': sub_ism_interval.chromosome,
                      'start': str(sub_ism_interval.start),
                      'end': str(sub_ism_interval.end),
                      'strand': strand_map.get(
                          str(sub_ism_interval.strand), 'STRAND_UNSTRANDED'
                      ),
                  },
                  'organism': f'ORGANISM_{organism.name}',
                  'variantScorers': _format_variant_scorers_for_json(
                      variant_scorers
                  ),
                  'mergeStrandedGeneTracks': merge_stranded_gene_tracks,
              },
          }]
      }

      if interval_variant:
        request_body['instances'][0]['data']['intervalVariant'] = {
            'chromosome': interval_variant.chromosome,
            'position': str(interval_variant.position),
            'referenceBases': interval_variant.reference_bases,
            'alternateBases': interval_variant.alternate_bases,
        }

      if self._model_version:
        request_body['instances'][0]['data'][
            'modelVersion'
        ] = self._model_version

      with self._http_client.stream(
          'POST',
          self._vertex_ai_url,
          json=request_body,
      ) as response:
        response.raise_for_status()
        response_protos = self._iter_response_protos(
            response, dna_model_service_pb2.ScoreIsmVariantResponse
        )
        return dna_client._make_score_variant_output(  # pylint: disable=protected-access
            response_protos, interval=interval
        )

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=max_workers
    ) as executor:
      futures = [
          executor.submit(_score_ism_variant, sub_ism_interval)
          for sub_ism_interval in ism_intervals
      ]
      ism_scores = []
      for future in tqdm.auto.tqdm(
          concurrent.futures.as_completed(futures),
          total=len(futures),
          disable=not progress_bar,
      ):
        ism_scores.extend(future.result())

    # Group scores by variant.
    ism_scores_by_variant: dict[str, list[anndata.AnnData]] = {}
    for variant_score in ism_scores:
      ism_scores_by_variant.setdefault(
          str(variant_score.uns['variant']), []
      ).append(variant_score)

    return list(ism_scores_by_variant.values())


def retry_http(
    function: _RetryableFunction,
    *,
    max_attempts: int = 5,
    initial_backoff: float = 1.25,
    backoff_multiplier: float = 1.5,
    retry_status_codes: Container[int] = frozenset([429, 503]),
    jitter: float = 0.2,
) -> _RetryableFunction:
  """Decorator that retries when an HTTP request fails with a retryable code.

  Arguments:
    function: Callable to retry.
    max_attempts: Maximum number of attempts to make.
    initial_backoff: Initial backoff time in seconds.
    backoff_multiplier: Backoff multiplier to apply on each retry.
    retry_status_codes: Set of status codes to retry on.
    jitter: Jitter to apply to the backoff time.

  Returns:
    A decorator that retries the function on retryable HTTP errors.
  """
  if backoff_multiplier < 1.0:
    raise ValueError('Backoff multiplier must be >= 1.0.')

  @functools.wraps(function)
  def wrapper(*args, **kwargs):
    attempt = 0
    current_backoff = initial_backoff + (
        random.uniform(-jitter, jitter) * initial_backoff
    )
    while True:
      try:
        attempt += 1
        return function(*args, **kwargs)
      except httpx.HTTPStatusError as e:
        if (
            e.response.status_code not in retry_status_codes
            or attempt >= max_attempts
        ):
          raise e
        time.sleep(current_backoff)
        current_backoff *= backoff_multiplier

  return typing.cast(_RetryableFunction, wrapper)


class GoogleAuth(httpx.Auth):
  """Custom httpx Auth class for Google Cloud Application Default Credentials."""

  def __init__(self, credentials: google.auth.credentials.Credentials):
    self._credentials = credentials

  def apply_headers(self, headers: dict[str, str]) -> None:
    if not self._credentials.valid:
      self._credentials.refresh(google.auth.transport.requests.Request())
    headers['Authorization'] = f'Bearer {self._credentials.token}'

  def auth_flow(
      self, request: Any
  ) -> Generator[Any, Any, None]:
    self.apply_headers(request.headers)
    yield request


def create_http_client(
    *,
    vertex_ai_url: str,
    model_version: dna_client.ModelVersion | str | None = None,
    timeout: float | None = None,
    service_account: str | None = None,
    token: str | None = None,
    credentials: google.auth.credentials.Credentials | None = None,
) -> HttpDnaClient:
  """Creates a model client that connects to a Vertex AI HTTP endpoint."""
  headers = {
      'content-type': 'application/json',
  }

  resolved_creds = credentials
  if token:
    headers['Authorization'] = f'Bearer {token}'
    http_client = httpx.Client(headers=headers, timeout=timeout)
  else:
    scopes = [
        'https://www.googleapis.com/auth/cloud-platform',
        'https://www.googleapis.com/auth/cloud-platform.read-only',
    ]
    if resolved_creds is None:
      source_credentials, _ = google.auth.default(scopes=scopes)
      if service_account:
        resolved_creds = impersonated_credentials.Credentials(
            source_credentials=source_credentials,
            target_principal=service_account,
            target_scopes=scopes,
        )
      else:
        resolved_creds = source_credentials

    http_client = httpx.Client(
        auth=GoogleAuth(resolved_creds),
        headers=headers,
        timeout=timeout,
    )

  return HttpDnaClient(
      http_client=http_client,
      model_version=model_version,
      vertex_ai_url=vertex_ai_url,
      credentials=resolved_creds,
      use_static_token=bool(token),
  )
