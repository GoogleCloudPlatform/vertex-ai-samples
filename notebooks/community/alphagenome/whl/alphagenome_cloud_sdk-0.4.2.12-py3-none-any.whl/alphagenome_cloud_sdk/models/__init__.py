# Copyright 2025 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""AlphaGenome Cloud SDK model clients (HTTP and gRPC)."""

import importlib
import typing
from typing import Any

if typing.TYPE_CHECKING:
  from google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top
  from google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk.models import dna_client_http  # pylint: disable=g-import-not-at-top

  GrpcDnaClient = dna_client_grpc.GrpcDnaClient
  VertexAiPredictionChannel = dna_client_grpc.VertexAiPredictionChannel
  create_grpc_client = dna_client_grpc.create_grpc_client
  create_local_client = dna_client_grpc.create_local_client
  create_vertex_client = dna_client_grpc.create_vertex_client
  HttpDnaClient = dna_client_http.HttpDnaClient
  create_http_client = dna_client_http.create_http_client

_GRPC_EXPORTS = frozenset({
    "GrpcDnaClient",
    "VertexAiPredictionChannel",
    "create_grpc_client",
    "create_local_client",
    "create_vertex_client",
})

_HTTP_EXPORTS = frozenset({
    "HttpDnaClient",
    "create_http_client",
})


def _import_submodule(name: str) -> Any:
  try:
    return importlib.import_module(
        "google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk"
        f".src.alphagenome_cloud_sdk.models.{name}"
    )
  except ImportError:
    return importlib.import_module(f"alphagenome_cloud_sdk.models.{name}")


def __getattr__(name: str) -> Any:  # pylint: disable=invalid-name
  """Lazily loads dna_client_grpc or dna_client_http on attribute access."""
  if name in ("dna_client_grpc", "dna_client_http"):
    return _import_submodule(name)
  if name in _GRPC_EXPORTS:
    return getattr(_import_submodule("dna_client_grpc"), name)
  if name in _HTTP_EXPORTS:
    return getattr(_import_submodule("dna_client_http"), name)
  raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "GrpcDnaClient",
    "HttpDnaClient",
    "VertexAiPredictionChannel",
    "create_grpc_client",
    "create_http_client",
    "create_local_client",
    "create_vertex_client",
    "dna_client_grpc",
    "dna_client_http",
]
