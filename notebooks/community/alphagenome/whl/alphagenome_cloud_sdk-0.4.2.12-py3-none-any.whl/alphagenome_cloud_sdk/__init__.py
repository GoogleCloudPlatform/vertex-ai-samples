# Copyright 2025 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""AlphaGenome Cloud SDK (HTTP and gRPC clients for Vertex AI)."""

import importlib
import typing
from typing import Any

if typing.TYPE_CHECKING:
  from google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk import auth  # pylint: disable=g-import-not-at-top
  from google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top
  from google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk.models import dna_client_http  # pylint: disable=g-import-not-at-top

  GoogleAuthMetadataPlugin = auth.GoogleAuthMetadataPlugin
  GrpcDnaClient = dna_client_grpc.GrpcDnaClient
  VertexAiPredictionChannel = dna_client_grpc.VertexAiPredictionChannel
  create_grpc_client = dna_client_grpc.create_grpc_client
  create_local_client = dna_client_grpc.create_local_client
  create_vertex_client = dna_client_grpc.create_vertex_client
  HttpDnaClient = dna_client_http.HttpDnaClient
  create_http_client = dna_client_http.create_http_client

_GRPC_EXPORTS = frozenset({
    "GrpcDnaClient",
    "VertexAiPredictionChannel",
    "create_grpc_client",
    "create_local_client",
    "create_vertex_client",
})

_HTTP_EXPORTS = frozenset({
    "HttpDnaClient",
    "create_http_client",
})


def _import_module(google3_path: str, standalone_path: str) -> Any:
  try:
    return importlib.import_module(google3_path)
  except ImportError:
    return importlib.import_module(standalone_path)


def __getattr__(name: str) -> Any:  # pylint: disable=invalid-name
  """Lazily resolves HTTP and gRPC client exports on attribute access."""
  if name == "GoogleAuthMetadataPlugin":
    auth_mod = _import_module(
        "google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk.auth",
        "alphagenome_cloud_sdk.auth",
    )
    return getattr(auth_mod, name)
  if name in _GRPC_EXPORTS:
    grpc_mod = _import_module(
        "google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk.models.dna_client_grpc",
        "alphagenome_cloud_sdk.models.dna_client_grpc",
    )
    return getattr(grpc_mod, name)
  if name in _HTTP_EXPORTS:
    http_mod = _import_module(
        "google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk.models.dna_client_http",
        "alphagenome_cloud_sdk.models.dna_client_http",
    )
    return getattr(http_mod, name)
  raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "GoogleAuthMetadataPlugin",
    "GrpcDnaClient",
    "HttpDnaClient",
    "VertexAiPredictionChannel",
    "create_grpc_client",
    "create_http_client",
    "create_local_client",
    "create_vertex_client",
]
