# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""End-to-end test client exercising all 6 DnaModelService RPC methods."""

from collections.abc import Sequence
import time
import typing

from absl import app
from absl import flags
from absl import logging
from alphagenome.data import genome

if typing.TYPE_CHECKING:
  from alphagenome.models.v1 import dna_client as dna_client_lib  # pylint: disable=g-import-not-at-top
  from alphagenome.models.v1 import dna_model  # pylint: disable=g-import-not-at-top
  from alphagenome.models.v1 import dna_output  # pylint: disable=g-import-not-at-top
  from google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top
else:
  try:
    from alphagenome.models.v1 import dna_client as dna_client_lib  # pylint: disable=g-import-not-at-top
    from alphagenome.models.v1 import dna_model  # pylint: disable=g-import-not-at-top
    from alphagenome.models.v1 import dna_output  # pylint: disable=g-import-not-at-top
  except ImportError:
    from alphagenome.models import dna_client as dna_client_lib  # pylint: disable=g-import-not-at-top
    from alphagenome.models import dna_model  # pylint: disable=g-import-not-at-top
    from alphagenome.models import dna_output  # pylint: disable=g-import-not-at-top

  try:
    from google3.cloud.ai.science.models.alphagenome.alphagenome_cloud_sdk.src.alphagenome_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top
  except ImportError:
    from alphagenome_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top

_ENDPOINT = flags.DEFINE_string(
    'endpoint',
    'localhost:8081',
    'gRPC server address or Vertex AI endpoint resource name.',
)
_INSECURE = flags.DEFINE_bool(
    'insecure',
    False,
    'Use an insecure gRPC channel.',
)
_TOKEN = flags.DEFINE_string(
    'token',
    None,
    'Optional explicit OAuth2 Bearer token.',
)


def main(argv: Sequence[str]) -> None:
  if len(argv) > 1:
    raise app.UsageError('Too many command-line arguments.')

  logging.info('=== Connecting to %s ===', _ENDPOINT.value)
  if _INSECURE.value:
    dna_client = dna_client_grpc.GrpcDnaClient.create_local_client(
        address=_ENDPOINT.value,
    )
  else:
    dna_client = dna_client_grpc.GrpcDnaClient.create_vertex_client(
        endpoint=_ENDPOINT.value,
        token=_TOKEN.value,
    )

  interval = genome.Interval(
      chromosome='chr22',
      start=36150498,
      end=36150498 + dna_client_lib.SEQUENCE_LENGTH_16KB,
  )
  variant = genome.Variant(
      chromosome='chr22',
      position=36158000,
      reference_bases='A',
      alternate_bases='G',
  )

  # 1. GetMetadata
  t0 = time.time()
  logging.info('[1/6] Testing output_metadata (GetMetadata)...')
  metadata = dna_client.output_metadata(dna_model.Organism.HOMO_SAPIENS)
  logging.info(
      '[1/6] PASS (%.2fs): metadata retrieved (atac tracks=%d)',
      time.time() - t0,
      len(metadata.atac) if metadata.atac is not None else 0,
  )

  # 2. PredictSequence
  t0 = time.time()
  logging.info('[2/6] Testing predict_sequence (PredictSequence)...')
  seq = 'ACGT' * (dna_client_lib.SEQUENCE_LENGTH_16KB // 4)
  seq_out = dna_client.predict_sequence(
      sequence=seq,
      organism=dna_model.Organism.HOMO_SAPIENS,
      requested_outputs=[dna_output.OutputType.ATAC],
      ontology_terms=['UBERON:0001114'],
  )
  if seq_out.atac is None:
    raise RuntimeError('Expected non-None ATAC output from predict_sequence.')
  logging.info(
      '[2/6] PASS (%.2fs): shape=%s',
      time.time() - t0,
      seq_out.atac.values.shape,
  )

  # 3. PredictInterval
  t0 = time.time()
  logging.info('[3/6] Testing predict_interval (PredictInterval)...')
  int_out = dna_client.predict_interval(
      interval=interval,
      organism=dna_model.Organism.HOMO_SAPIENS,
      requested_outputs=[
          dna_output.OutputType.ATAC,
          dna_output.OutputType.RNA_SEQ,
      ],
      ontology_terms=['UBERON:0001114'],
  )
  if int_out.atac is None or int_out.rna_seq is None:
    raise RuntimeError(
        'Expected non-None ATAC and RNA_SEQ outputs from predict_interval.'
    )
  logging.info(
      '[3/6] PASS (%.2fs): ATAC=%s, RNA_SEQ=%s',
      time.time() - t0,
      int_out.atac.values.shape,
      int_out.rna_seq.values.shape,
  )

  # 4. PredictVariant
  t0 = time.time()
  logging.info('[4/6] Testing predict_variant (PredictVariant)...')
  var_out = dna_client.predict_variant(
      interval=interval,
      variant=variant,
      organism=dna_model.Organism.HOMO_SAPIENS,
      requested_outputs=[dna_output.OutputType.ATAC],
      ontology_terms=['UBERON:0001114'],
  )
  if var_out.reference.atac is None or var_out.alternate.atac is None:
    raise RuntimeError(
        'Expected non-None reference and alternate ATAC outputs from'
        ' predict_variant.'
    )
  logging.info(
      '[4/6] PASS (%.2fs): ref=%s, alt=%s',
      time.time() - t0,
      var_out.reference.atac.values.shape,
      var_out.alternate.atac.values.shape,
  )

  # 5. ScoreInterval
  t0 = time.time()
  logging.info('[5/6] Testing score_interval (ScoreInterval)...')
  int_scores = dna_client.score_interval(
      interval=interval,
      organism=dna_model.Organism.HOMO_SAPIENS,
  )
  if not int_scores:
    raise RuntimeError('Expected non-empty score_interval results.')
  logging.info(
      '[5/6] PASS (%.2fs): %d AnnData score objects returned, first shape=%s',
      time.time() - t0,
      len(int_scores),
      int_scores[0].shape,
  )

  # 6. ScoreVariant & ScoreIsmVariant
  t0 = time.time()
  logging.info('[6a/6] Testing score_variant (ScoreVariant)...')
  var_scores = dna_client.score_variant(
      interval=interval,
      variant=variant,
      organism=dna_model.Organism.HOMO_SAPIENS,
  )
  if not var_scores:
    raise RuntimeError('Expected non-empty score_variant results.')
  logging.info(
      '[6a/6] PASS (%.2fs): %d AnnData variant score objects returned, first'
      ' shape=%s',
      time.time() - t0,
      len(var_scores),
      var_scores[0].shape,
  )

  t0 = time.time()
  logging.info('[6b/6] Testing score_ism_variants (ScoreIsmVariant)...')
  ism_interval = genome.Interval(
      chromosome='chr22',
      start=36158000,
      end=36158002,
  )
  ism_scores = dna_client.score_ism_variants(
      interval=interval,
      ism_interval=ism_interval,
      organism=dna_model.Organism.HOMO_SAPIENS,
      max_workers=1,
  )
  if not ism_scores:
    raise RuntimeError('Expected non-empty score_ism_variants results.')
  logging.info(
      '[6b/6] PASS (%.2fs): %d ISM variants scored',
      time.time() - t0,
      len(ism_scores),
  )

  logging.info('=== ALL 6 RPC METHODS PASSED SUCCESSFULLY ===')


if __name__ == '__main__':
  app.run(main)
