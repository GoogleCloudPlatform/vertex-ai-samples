# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""HTTP client implementation for interacting with AlphaGenome v2 IaaS endpoints on Google Cloud."""

import base64
import codecs
from collections.abc import Callable, Iterator, Mapping, Sequence
import json
import re
from typing import Any
import urllib.error
import urllib.request

import google.auth
import google.auth.credentials
import google.auth.transport.requests
from google.protobuf import json_format
from google.protobuf import message
import grpc

try:
  import httpx as _real_httpx  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

  httpx: Any = _real_httpx
except ImportError:

  class _FallbackHttpxRequest:
    """Minimal HTTP request object for transport testing when httpx is absent."""

    def __init__(
        self,
        method: str,
        url: str,
        content: bytes = b'',
        headers: dict[str, str] | None = None,
    ):
      self.method = method
      self.url = url
      self.content = content
      self.headers = headers or {}

  class _FallbackHttpxResponse:
    """Minimal HTTP response object for transport testing when httpx is absent."""

    def __init__(
        self,
        status_code: int = 200,
        content: bytes = b'',
        headers: dict[str, str] | None = None,
    ):
      self.status_code = status_code
      self.content = content
      self.headers = headers or {}

    @property
    def text(self) -> str:
      return self.content.decode('utf-8', errors='replace')

  class _FallbackMockTransport:
    """Minimal MockTransport wrapping a request handler callable."""

    def __init__(self, handler: Callable[[_FallbackHttpxRequest], Any]):
      self.handler = handler

  class _FallbackHttpxClient:
    """Minimal HTTP client delegating to MockTransport when provided."""

    def __init__(
        self,
        transport: _FallbackMockTransport | None = None,
        timeout: float | None = 600.0,
    ):
      self._transport = transport
      self.timeout = timeout

    def post(
        self,
        url: str,
        *,
        content: bytes = b'',
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> Any:
      """Sends a POST request through the configured MockTransport."""
      del timeout
      if self._transport is None:
        raise RuntimeError('No transport configured on fallback HTTP client.')
      req = _FallbackHttpxRequest(
          'POST', url, content=content, headers=headers
      )
      return self._transport.handler(req)

    def close(self) -> None:
      """Closes the fallback client."""

  class _FallbackHttpxModule:
    """Fallback httpx module namespace when httpx is not installed."""

    Request = _FallbackHttpxRequest  # pylint: disable=invalid-name
    Response = _FallbackHttpxResponse  # pylint: disable=invalid-name
    MockTransport = _FallbackMockTransport  # pylint: disable=invalid-name
    Client = _FallbackHttpxClient  # pylint: disable=invalid-name

  httpx = _FallbackHttpxModule()

try:
  from alphagenome import tensor_utils  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
except ImportError:
  from alphagenome2 import tensor_utils  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

try:
  from alphagenome.data import gene_expression_data  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.data import genome  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.data import junction_data  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.data import ontology  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.data import track_data  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import dna_client  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import dna_model  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import dna_output  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import interval_scorers as interval_scorers_lib  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import model_condition  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import variant_scorers as variant_scorers_lib  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
except ImportError:
  from alphagenome2.data import gene_expression_data  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.data import genome  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.data import junction_data  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.data import ontology  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.data import track_data  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import dna_client  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import dna_model  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import dna_output  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import interval_scorers as interval_scorers_lib  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import model_condition  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import variant_scorers as variant_scorers_lib  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

try:
  from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk import auth  # pylint: disable=g-import-not-at-top
  from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top
  from google3.google.api import httpbody_pb2  # pylint: disable=g-import-not-at-top
except ImportError:
  from alphagenomev2_cloud_sdk import auth  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenomev2_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from google.api import httpbody_pb2  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

SEQUENCE_LENGTH_16KB = dna_client.SEQUENCE_LENGTH_16KB
SEQUENCE_LENGTH_100KB = dna_client.SEQUENCE_LENGTH_100KB
SEQUENCE_LENGTH_500KB = dna_client.SEQUENCE_LENGTH_500KB
SEQUENCE_LENGTH_1MB = dna_client.SEQUENCE_LENGTH_1MB
SUPPORTED_SEQUENCE_LENGTHS = dna_client.SUPPORTED_SEQUENCE_LENGTHS
MAX_CONDITIONING_CELLS = dna_client.MAX_CONDITIONING_CELLS
MAX_ISM_INTERVAL_WIDTH = dna_client.MAX_ISM_INTERVAL_WIDTH
MAX_VARIANT_SCORERS_PER_REQUEST = dna_client.MAX_VARIANT_SCORERS_PER_REQUEST
DEFAULT_MAX_WORKERS = dna_model.DEFAULT_MAX_WORKERS

ModelVersion = dna_client.ModelVersion
Organism = dna_model.Organism
OutputType = dna_output.OutputType
Output = dna_output.Output
OutputMetadata = dna_output.OutputMetadata
VariantOutput = dna_output.VariantOutput
InputGradientsOutput = dna_client.InputGradientsOutput
validate_sequence_length = dna_client.validate_sequence_length

_RPC_METHOD_TO_REQUEST_TYPE: dict[str, str] = {
    'PredictSequence': 'predict_sequence',
    'PredictInterval': 'predict_interval',
    'PredictVariant': 'predict_variant',
    'ScoreInterval': 'score_interval',
    'ScoreVariant': 'score_variant',
    'ScoreIsmVariant': 'score_ism_variant',
    'EncodeCells': 'encode_cells',
    'PredictIntervalGradients': 'predict_interval_gradients',
    'GetMetadata': 'get_metadata',
    'GetObservedMetadata': 'get_observed_metadata',
    'GetSupportedConditions': 'get_supported_conditions',
}

_HTTP_STATUS_TO_GRPC_CODE: dict[int, grpc.StatusCode] = {
    400: grpc.StatusCode.INVALID_ARGUMENT,
    401: grpc.StatusCode.UNAUTHENTICATED,
    403: grpc.StatusCode.PERMISSION_DENIED,
    404: grpc.StatusCode.NOT_FOUND,
    408: grpc.StatusCode.DEADLINE_EXCEEDED,
    409: grpc.StatusCode.ALREADY_EXISTS,
    429: grpc.StatusCode.RESOURCE_EXHAUSTED,
    499: grpc.StatusCode.CANCELLED,
    501: grpc.StatusCode.UNIMPLEMENTED,
    503: grpc.StatusCode.UNAVAILABLE,
    504: grpc.StatusCode.DEADLINE_EXCEEDED,
}


class HttpRpcError(dna_client_grpc.GrpcProxyRpcError):  # pyrefly: ignore[invalid-inheritance]
  """gRPC-compatible error raised when a Vertex AI HTTP or OpenMaaS request fails."""


def _method_to_request_type(method_name: str) -> str:
  """Converts a DnaModelService gRPC method name or path to snake_case request_type."""
  short_name = method_name.strip().rsplit('/', 1)[-1]
  return _RPC_METHOD_TO_REQUEST_TYPE.get(short_name, short_name)


def _request_to_data_dict(req: Any) -> dict[str, Any]:
  """Converts a protobuf request message or mapping into a JSON-serializable dict."""
  if isinstance(req, message.Message):
    return json_format.MessageToDict(req)
  if isinstance(req, Mapping):
    return dict(req)
  if isinstance(req, (str, bytes)):
    try:
      text = req.decode('utf-8') if isinstance(req, bytes) else req
      parsed = json.loads(text)
      if isinstance(parsed, dict):
        return parsed
    except (UnicodeDecodeError, json.JSONDecodeError):
      pass
  raise TypeError(
      f'Expected protobuf Message or dict for HTTP request, got {type(req)}'
  )


class _HttpWrappedCallStream(dna_client_grpc._WrappedCallStream):  # pylint: disable=protected-access  # pyrefly: ignore[invalid-inheritance]
  """Wraps an HTTP/JSON HttpBody stream and decodes proto_b64 chunks."""

  def __init__(
      self,
      call: Any,
      response_deserializer: Callable[[bytes], Any] | None,
      *,
      track_usage: bool = False,
  ):
    super().__init__(call, response_deserializer)
    self._track_usage = track_usage
    self.usage_metadata: dict[str, Any] | None = None

  def _generate(self) -> Iterator[Any]:
    decoder = json.JSONDecoder()
    utf8_decoder = codecs.getincrementaldecoder('utf-8')()
    buffer = ''
    for raw_http_body in self._call:
      buffer += utf8_decoder.decode(raw_http_body.data, final=False)
      while buffer:
        stripped = buffer.lstrip(' \t\r\n,[]')
        if stripped.startswith('data:'):
          stripped = stripped[len('data:') :].lstrip(' \t')
        if stripped.startswith('[DONE]'):
          buffer = stripped[len('[DONE]') :]
          continue
        buffer = stripped
        if not buffer:
          break
        try:
          chunk_dict, end_idx = decoder.raw_decode(buffer)
        except json.JSONDecodeError:
          break
        buffer = buffer[end_idx:]
        if not isinstance(chunk_dict, dict):
          continue
        if 'error' in chunk_dict and 'proto_b64' not in chunk_dict:
          err_obj = chunk_dict['error']
          err_msg = (
              err_obj.get('message', str(err_obj))
              if isinstance(err_obj, dict)
              else str(err_obj)
          )
          raise HttpRpcError(grpc.StatusCode.INTERNAL, err_msg)
        if self._track_usage and 'usageMetadata' in chunk_dict:
          self.usage_metadata = chunk_dict['usageMetadata']
        if 'proto_b64' in chunk_dict:
          proto_bytes = base64.b64decode(chunk_dict['proto_b64'])
          if self._deserializer is not None:
            yield self._deserializer(proto_bytes)
          else:
            yield proto_bytes
        elif 'usageMetadata' not in chunk_dict:
          raise ValueError(
              'Missing "proto_b64" field in response chunk:'
              f' {list(chunk_dict.keys())}'
          )


class _HttpInvokeCall(grpc.Call):
  """Streams HttpBody chunks from a Vertex AI HTTP POST (:streamRawPredict or /science/inference) call."""

  def __init__(
      self,
      http_url: str,
      payload: bytes,
      headers: dict[str, str],
      timeout: float | None = None,
      http_client: Any = None,
  ):
    self._http_url = http_url
    self._payload = payload
    self._headers = headers
    self._timeout = timeout
    self._http_client = http_client
    self._iterator: Iterator[httpbody_pb2.HttpBody] | None = None

  def _generate(self) -> Iterator[httpbody_pb2.HttpBody]:
    if (
        self._http_client is not None
        and getattr(self._http_client, '_transport', True) is not None
    ):
      resp = self._http_client.post(
          self._http_url,
          content=self._payload,
          headers=self._headers,
          timeout=self._timeout,
      )
      if resp.status_code >= 400:
        err_body = resp.text
        grpc_code = _HTTP_STATUS_TO_GRPC_CODE.get(
            resp.status_code, grpc.StatusCode.INTERNAL
        )
        raise HttpRpcError(
            grpc_code,
            f'HTTP {resp.status_code}: {err_body}',
            http_status=resp.status_code,
        )
      yield httpbody_pb2.HttpBody(
          content_type='application/json',
          data=resp.content,
      )
      return

    req = urllib.request.Request(
        self._http_url,
        data=self._payload,
        headers=self._headers,
        method='POST',
    )
    try:
      resp = urllib.request.urlopen(req, timeout=self._timeout)
    except urllib.error.HTTPError as e:
      err_body = e.read().decode('utf-8', errors='replace')
      grpc_code = _HTTP_STATUS_TO_GRPC_CODE.get(
          e.code, grpc.StatusCode.INTERNAL
      )
      raise HttpRpcError(
          grpc_code,
          f'HTTP {e.code}: {err_body}',
          http_status=e.code,
      ) from e
    except urllib.error.URLError as e:
      raise HttpRpcError(
          grpc.StatusCode.UNAVAILABLE,
          f'Connection error: {e.reason}',
      ) from e

    with resp:
      read_fn: Callable[[int], bytes] = (
          getattr(resp, 'read1', None) or resp.read
      )
      while True:
        chunk = read_fn(65536)
        if not chunk:
          break
        yield httpbody_pb2.HttpBody(
            content_type='application/json',
            data=chunk,
        )

  def __iter__(self) -> Iterator[httpbody_pb2.HttpBody]:
    if self._iterator is None:
      self._iterator = self._generate()
    return self

  def __next__(self) -> httpbody_pb2.HttpBody:
    if self._iterator is None:
      self._iterator = self._generate()
    return next(self._iterator)

  def cancel(self) -> bool:
    return False

  def is_active(self) -> bool:
    return False

  def time_remaining(self) -> float | None:
    return None

  def initial_metadata(self) -> Sequence[tuple[str, str | bytes]]:
    return ()

  def trailing_metadata(self) -> Sequence[tuple[str, str | bytes]]:
    return ()

  def code(self) -> grpc.StatusCode:
    return grpc.StatusCode.OK

  def details(self) -> str:
    return ''

  def add_callback(self, callback: Callable[[Any], None]) -> bool:
    del callback
    return False


def _make_http_invoke_callable(
    http_url: str,
    auth_plugin: auth.GoogleAuthMetadataPlugin,
    http_client: Any = None,
    default_timeout: float | None = None,
) -> Callable[..., _HttpInvokeCall]:
  """Creates a callable that sends HTTPS POST requests to Vertex AI."""

  def _http_invoke(
      payload: bytes,
      timeout: float | None = None,
  ) -> _HttpInvokeCall:
    token = auth_plugin.get_token()
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json',
    }
    return _HttpInvokeCall(
        http_url=http_url,
        payload=payload,
        headers=headers,
        timeout=timeout if timeout is not None else default_timeout,
        http_client=http_client,
    )

  return _http_invoke


class _VertexAiHttpUnaryUnaryMultiCallable(grpc.UnaryUnaryMultiCallable):
  """Maps DnaModelServiceV2 unary-unary RPC to a Vertex AI HTTP POST call."""

  def __init__(
      self,
      underlying_invoke: Callable[..., Any],
      method_name: str,
      request_serializer: Callable[[Any], bytes] | None,
      response_deserializer: Callable[[bytes], Any] | None,
      *,
      model_name: str | None = None,
      include_maas_envelope: bool = False,
      track_usage: bool = False,
      usage_callback: Callable[[dict[str, Any] | None], None] | None = None,
  ):
    self._underlying_invoke = underlying_invoke
    self._method_name = method_name
    self._serializer = request_serializer
    self._deserializer = response_deserializer
    self._model_name = (
        model_name.strip().removeprefix('google/')
        if model_name is not None
        else None
    )
    self._include_maas_envelope = include_maas_envelope
    self._track_usage = track_usage
    self._usage_callback = usage_callback

  def with_call(
      self,
      request: Any,
      timeout: float | None = None,
      metadata: Sequence[tuple[str, str | bytes]] | None = None,
      credentials: grpc.CallCredentials | None = None,
      wait_for_ready: bool | None = None,
      compression: grpc.Compression | None = None,
  ) -> tuple[Any, grpc.Call]:
    del metadata, credentials, wait_for_ready, compression
    request_type = _method_to_request_type(self._method_name)
    envelope: dict[str, Any] = {
        'instances': [{
            'request_type': request_type,
            'data': _request_to_data_dict(request),
        }],
    }
    if self._include_maas_envelope and self._model_name:
      envelope['model'] = self._model_name
      envelope['stream'] = True

    raw_call = self._underlying_invoke(
        json.dumps(envelope).encode('utf-8'),
        timeout=timeout,
    )
    call_stream = _HttpWrappedCallStream(
        raw_call,
        self._deserializer,
        track_usage=self._track_usage,
    )
    results = list(call_stream)
    if self._usage_callback is not None:
      self._usage_callback(call_stream.usage_metadata)
    if not results:
      raise HttpRpcError(
          grpc.StatusCode.INTERNAL,
          f'Empty HTTP response stream from {self._method_name}',
      )
    return dna_client_grpc.merge_response_protos(results), call_stream

  def __call__(
      self,
      request: Any,
      timeout: float | None = None,
      metadata: Sequence[tuple[str, str | bytes]] | None = None,
      credentials: grpc.CallCredentials | None = None,
      wait_for_ready: bool | None = None,
      compression: grpc.Compression | None = None,
  ) -> Any:
    response, _ = self.with_call(
        request,
        timeout=timeout,
        metadata=metadata,
        credentials=credentials,
        wait_for_ready=wait_for_ready,
        compression=compression,
    )
    return response

  def future(
      self,
      request: Any,
      timeout: float | None = None,
      metadata: Sequence[tuple[str, str | bytes]] | None = None,
      credentials: grpc.CallCredentials | None = None,
      wait_for_ready: bool | None = None,
      compression: grpc.Compression | None = None,
  ) -> Any:
    raise NotImplementedError('Async futures are not supported on proxy calls.')


class VertexAiHttpChannel(grpc.Channel):
  """A gRPC channel adapter translating DnaModelServiceV2 RPCs to Vertex AI HTTP POST."""

  def __init__(
      self,
      *,
      http_url: str,
      auth_plugin: auth.GoogleAuthMetadataPlugin,
      http_client: Any = None,
      default_timeout: float | None = None,
  ):
    self._http_url = http_url
    self._auth_plugin = auth_plugin
    self._http_client = http_client
    self._default_timeout = default_timeout
    self._invoke = _make_http_invoke_callable(
        http_url,
        auth_plugin,
        http_client=http_client,
        default_timeout=default_timeout,
    )

  def unary_unary(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    del args, kwargs
    return _VertexAiHttpUnaryUnaryMultiCallable(
        self._invoke,
        method_name=method,
        request_serializer=request_serializer,
        response_deserializer=response_deserializer,
        include_maas_envelope=False,
        track_usage=False,
    )

  def stream_stream(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    del method, request_serializer, response_deserializer, args, kwargs
    raise NotImplementedError(
        'DnaModelServiceV2 only supports unary-unary RPCs.'
    )

  def unary_stream(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    del method, request_serializer, response_deserializer, args, kwargs
    raise NotImplementedError(
        'DnaModelServiceV2 only supports unary-unary RPCs.'
    )

  def stream_unary(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    del method, request_serializer, response_deserializer, args, kwargs
    raise NotImplementedError(
        'DnaModelServiceV2 only supports unary-unary RPCs.'
    )

  def subscribe(
      self, callback: Callable[[Any], None], try_to_connect: bool = False
  ) -> None:
    del callback, try_to_connect

  def unsubscribe(self, callback: Callable[[Any], None]) -> None:
    del callback

  def close(self) -> None:
    if self._http_client is not None and hasattr(self._http_client, 'close'):
      self._http_client.close()

  def __enter__(self) -> 'VertexAiHttpChannel':
    return self

  def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
    self.close()


def _resolve_http_url(
    vertex_ai_url: str | None,
    endpoint: str,
    project: str | None,
    location: str,
) -> str:
  """Resolves the Vertex AI IaaS HTTP `:streamRawPredict` URL."""
  if (
      vertex_ai_url
      and vertex_ai_url.strip().startswith(('https://', 'http://'))
      and (
          ':streamRawPredict' in vertex_ai_url
          or '/predict' in vertex_ai_url
          or '/science/inference' in vertex_ai_url
          or '/invoke/' in vertex_ai_url
      )
  ):
    return vertex_ai_url.strip()

  target = (vertex_ai_url or endpoint).strip()
  if not target:
    raise ValueError(
        'A Vertex AI endpoint ID, resource name, dedicated DNS address, or'
        ' vertex_ai_url is required for create_http_client. For Vertex AI'
        ' OpenMaaS, use create_maas_client().'
    )

  scheme = 'http' if target.startswith('http://') else 'https'
  cleaned_no_scheme = (
      target.removeprefix('https://').removeprefix('http://').rstrip('/')
  )
  if '.prediction.vertexai.goog' in cleaned_no_scheme:
    host_and_port = cleaned_no_scheme.split('/', 1)[0]
    host = (
        host_and_port[:-4]
        if host_and_port.endswith(':443')
        else host_and_port
    )
    ep_id = host.split('.', 1)[0]
    resolved_project = dna_client_grpc._resolve_project(project, target)  # pylint: disable=protected-access
    return (
        f'https://{host}/v1/projects/{resolved_project}/locations/{location}'
        f'/endpoints/{ep_id}:streamRawPredict'
    )

  proj_loc_match = re.search(
      r'projects/([^/]+)/locations/([^/]+)', cleaned_no_scheme
  )
  if proj_loc_match:
    resolved_project = proj_loc_match.group(1)
    resolved_location = proj_loc_match.group(2)
  else:
    resolved_project = dna_client_grpc._resolve_project(project, target)  # pylint: disable=protected-access
    resolved_location = location

  parsed_host: str | None = None
  path = cleaned_no_scheme
  if target.startswith(('https://', 'http://')):
    if '/' in cleaned_no_scheme:
      host_part, path_part = cleaned_no_scheme.split('/', 1)
      path = '/' + path_part
    else:
      host_part = cleaned_no_scheme
      path = ''
    parsed_host = (
        host_part[:-4]
        if scheme == 'https' and host_part.endswith(':443')
        else host_part
    )

  if '/endpoints/' in path:
    ep_id = path.split('/endpoints/', 1)[1].split('/')[0].split(':')[0]
  else:
    ep_id = path.strip('/').split(':')[0]

  host_for_url = parsed_host or f'{resolved_location}-aiplatform.googleapis.com'
  return (
      f'{scheme}://{host_for_url}/v1/projects/{resolved_project}'
      f'/locations/{resolved_location}/endpoints/{ep_id}:streamRawPredict'
  )


class HttpDnaClient(dna_client_grpc.CloudDnaClientMixin):
  """AlphaGenome v2 HTTP client for Vertex AI IaaS endpoints."""

  def __init__(
      self,
      http_client: httpx.Client,
      vertex_ai_url: str,
      credentials: google.auth.credentials.Credentials | None = None,
      *,
      token: str | None = None,
      service_account: str | None = None,
      model_version: ModelVersion | str | None = None,
      timeout: float | None = None,
      channel: grpc.Channel | None = None,
  ):
    self._http_client = http_client
    self._vertex_ai_url = vertex_ai_url
    self._credentials = credentials
    self._use_static_token = token is not None
    existing_auth_plugin = (
        getattr(channel, '_auth_plugin', None) if channel is not None else None
    )
    self._auth_plugin = existing_auth_plugin or auth.GoogleAuthMetadataPlugin(
        credentials=credentials,
        service_account=service_account,
        token=token,
    )
    client_timeout = getattr(http_client, 'timeout', None)
    if timeout is not None:
      resolved_timeout = timeout
    elif isinstance(client_timeout, (int, float)):
      resolved_timeout = float(client_timeout)
    else:
      resolved_timeout = None
    resolved_channel = channel or VertexAiHttpChannel(
        http_url=vertex_ai_url,
        auth_plugin=self._auth_plugin,
        http_client=http_client,
        default_timeout=resolved_timeout,
    )
    super().__init__(
        channel=resolved_channel,
        model_version=dna_client_grpc._parse_model_version(model_version),  # pylint: disable=protected-access
    )

  def validate_credentials(self) -> str:
    """Validates or refreshes Google Cloud credentials."""
    if self._use_static_token:
      return 'Credentials are valid.'
    self._auth_plugin.get_token()
    return 'Credentials are valid.'


def create_http_client(
    endpoint: str = '',
    *,
    endpoint_id: str | None = None,
    project: str | None = None,
    location: str = 'us-central1',
    vertex_ai_url: str | None = None,
    credentials: google.auth.credentials.Credentials | None = None,
    service_account: str | None = None,
    token: str | None = None,
    model_version: ModelVersion | str | None = None,
    timeout: float = 600.0,
) -> HttpDnaClient:
  """Creates an AlphaGenome v2 HTTP client for a Vertex AI IaaS endpoint.

  Args:
    endpoint: Vertex AI Endpoint ID, resource name, or dedicated DNS address.
    endpoint_id: Optional alias for `endpoint`.
    project: GCP Project ID. Defaults to the project discovered via
      `google.auth.default()` when not embedded in `endpoint`.
    location: GCP Region/Location (default: 'us-central1').
    vertex_ai_url: Optional full URL override for HTTP POST predictions.
    credentials: Optional google.auth credentials.
    service_account: Optional service account email for impersonation.
    token: Optional static OAuth2 bearer token.
    model_version: Optional model checkpoint version (e.g. 'FOLD_1').
    timeout: HTTP request timeout in seconds (default: 600.0).

  Returns:
    A configured HttpDnaClient instance.
  """
  if endpoint_id is not None:
    endpoint = endpoint_id

  resolved_url = _resolve_http_url(
      vertex_ai_url=vertex_ai_url,
      endpoint=endpoint,
      project=project,
      location=location,
  )
  http_client = httpx.Client(timeout=timeout)
  return HttpDnaClient(
      http_client=http_client,
      vertex_ai_url=resolved_url,
      credentials=credentials,
      token=token,
      service_account=service_account,
      model_version=model_version,
      timeout=timeout,
  )


create = create_http_client

__all__ = [
    'DEFAULT_MAX_WORKERS',
    'HttpDnaClient',
    'HttpRpcError',
    'InputGradientsOutput',
    'MAX_CONDITIONING_CELLS',
    'MAX_ISM_INTERVAL_WIDTH',
    'MAX_VARIANT_SCORERS_PER_REQUEST',
    'ModelVersion',
    'Organism',
    'Output',
    'OutputMetadata',
    'OutputType',
    'SEQUENCE_LENGTH_100KB',
    'SEQUENCE_LENGTH_16KB',
    'SEQUENCE_LENGTH_1MB',
    'SEQUENCE_LENGTH_500KB',
    'SUPPORTED_SEQUENCE_LENGTHS',
    'VariantOutput',
    'VertexAiHttpChannel',
    'create',
    'create_http_client',
    'dna_client',
    'dna_model',
    'dna_output',
    'gene_expression_data',
    'genome',
    'httpx',
    'interval_scorers_lib',
    'junction_data',
    'model_condition',
    'ontology',
    'tensor_utils',
    'track_data',
    'validate_sequence_length',
    'variant_scorers_lib',
]
