# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""gRPC client implementation for interacting with AlphaGenome v2 IaaS and local endpoints."""

from collections.abc import Callable, Iterator, Sequence
import concurrent.futures
import enum
import inspect
import re
from typing import Any

import anndata
import google.auth
import google.auth.credentials
from google.protobuf import message
import grpc
import numpy as np
import tqdm.auto

try:
  from alphagenome import tensor_utils  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
except ImportError:
  from alphagenome2 import tensor_utils  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

try:
  from alphagenome.models.v2 import dna_client  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
except ImportError:
  from alphagenome2.models.v2 import dna_client  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

try:
  from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk import auth  # pylint: disable=g-import-not-at-top
  from google3.google.cloud.aiplatform.v1 import prediction_service_pb2 as _g3_prediction_service_pb2  # pylint: disable=g-import-not-at-top

  prediction_service_pb2: Any = _g3_prediction_service_pb2
except ImportError:
  from alphagenomev2_cloud_sdk import auth  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from google.cloud.aiplatform_v1.types import prediction_service as _aiplatform_ps  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

  class _FallbackPredictionServicePb2:
    """Provides protobuf message classes for Vertex AI PredictionService outside google3."""

    StreamDirectRawPredictRequest = (  # pylint: disable=invalid-name
        _aiplatform_ps.StreamDirectRawPredictRequest.pb()
    )
    StreamDirectRawPredictResponse = (  # pylint: disable=invalid-name
        _aiplatform_ps.StreamDirectRawPredictResponse.pb()
    )

  prediction_service_pb2 = _FallbackPredictionServicePb2()

_DEFAULT_CHANNEL_OPTIONS: list[tuple[str, int | str]] = [
    ('grpc.max_receive_message_length', -1),
    ('grpc.max_send_message_length', -1),
    ('grpc.keepalive_time_ms', 30000),
    ('grpc.keepalive_timeout_ms', 10000),
    ('grpc.keepalive_permit_without_calls', 1),
    ('grpc.http2.max_pings_without_data', 0),
]

DEFAULT_TIMEOUT = 600.0

ModelVersion = dna_client.ModelVersion

# Protobuf enum value for Strand.STRAND_UNSTRANDED ('.').
_STRAND_UNSTRANDED_PROTO_VALUE = 3

# Maximum cells per EncodeCells RPC batch so requests stay strictly below
# Vertex AI's 10.000 MB per-message limit on shared gRPC and HTTP endpoints.
_MAX_ENCODE_CELLS_BATCH_SIZE = 256

_STREAMING_METHOD_MAP: dict[str, str] = {
    '/google.gdm.gdmscience.alphagenome.v2main.DnaModelServiceV2/PredictSequence': (
        '/google.gdm.gdmscience.alphagenome.v2main.DnaModelServiceV2/PredictSequenceStream'
    ),
    '/google.gdm.gdmscience.alphagenome.v2main.DnaModelServiceV2/PredictInterval': (
        '/google.gdm.gdmscience.alphagenome.v2main.DnaModelServiceV2/PredictIntervalStream'
    ),
    '/google.gdm.gdmscience.alphagenome.v2main.DnaModelServiceV2/PredictVariant': (
        '/google.gdm.gdmscience.alphagenome.v2main.DnaModelServiceV2/PredictVariantStream'
    ),
}


class GrpcProxyRpcError(grpc.RpcError, grpc.Call):
  """gRPC-compatible error raised when a proxied Vertex AI RPC fails."""

  def __init__(
      self,
      status_code: grpc.StatusCode,
      details: str,
      http_status: int | None = None,
  ):
    super().__init__(details)
    self._status_code = status_code
    self._details = details
    self.http_status = http_status

  def code(self) -> grpc.StatusCode:
    return self._status_code

  def details(self) -> str:
    return self._details

  def initial_metadata(self) -> Sequence[tuple[str, str | bytes]]:
    return ()

  def trailing_metadata(self) -> Sequence[tuple[str, str | bytes]]:
    return ()

  def cancel(self) -> bool:
    return False

  def is_active(self) -> bool:
    return False

  def time_remaining(self) -> float | None:
    return None

  def add_callback(self, callback: Callable[[Any], None]) -> bool:
    del callback
    return False


def _parse_model_version(
    model_version: ModelVersion | str | None,
) -> ModelVersion | None:
  """Resolves a string or enum into a `dna_client.ModelVersion` enum value."""
  if model_version is None:
    return None
  if isinstance(model_version, ModelVersion):
    return model_version
  if isinstance(model_version, enum.Enum):
    return ModelVersion[model_version.name]
  return ModelVersion[str(model_version).upper()]


def _normalize_strands_in_place(proto_msg: Any) -> None:
  """Defaults STRAND_UNSPECIFIED (0) to STRAND_UNSTRANDED (3) on metadata/intervals."""
  if not isinstance(proto_msg, message.Message):
    return
  desc = proto_msg.DESCRIPTOR
  if 'strand' in desc.fields_by_name and getattr(proto_msg, 'strand') == 0:
    setattr(proto_msg, 'strand', _STRAND_UNSTRANDED_PROTO_VALUE)
  if (
      desc.name == 'GeneExpressionData'
      and 'interval' in desc.fields_by_name
      and getattr(proto_msg, 'interval').strand == 0
  ):
    getattr(proto_msg, 'interval').strand = _STRAND_UNSTRANDED_PROTO_VALUE
  for field_desc, val in proto_msg.ListFields():
    if field_desc.message_type is None:
      continue
    if isinstance(val, message.Message):
      _normalize_strands_in_place(val)
    else:
      for elem in val:
        _normalize_strands_in_place(elem)


def _normalize_score_shapes_in_place(proto_msg: Any) -> None:
  """Normalizes 2D (n_obs, n_var) score tensors to 3D (1, n_obs, n_var)."""
  if not hasattr(proto_msg, 'outputs'):
    return
  for out in proto_msg.outputs:
    for data_field in ('variant_data', 'interval_data'):
      if hasattr(out, data_field) and out.HasField(data_field):
        data_msg = getattr(out, data_field)
        if hasattr(data_msg, 'values') and len(data_msg.values.shape) == 2:
          new_shape = [1, data_msg.values.shape[0], data_msg.values.shape[1]]
          del data_msg.values.shape[:]
          data_msg.values.shape.extend(new_shape)


def _merge_repeated_outputs(repeated_outputs: Any) -> None:
  """Concatenates split TrackData chunks sharing an output_type in-place."""
  if len(repeated_outputs) <= 1:
    return
  grouped: dict[int, list[Any]] = {}
  order: list[tuple[int | None, Any]] = []
  for item in repeated_outputs:
    if (
        hasattr(item, 'DESCRIPTOR')
        and 'track_data' in item.DESCRIPTOR.fields_by_name
        and item.HasField('track_data')
    ):
      out_type = item.output_type
      if out_type not in grouped:
        grouped[out_type] = [item]
        order.append((out_type, None))
      else:
        grouped[out_type].append(item)
    else:
      order.append((None, item))

  if all(len(chunks) == 1 for chunks in grouped.values()):
    return

  merged_items = []
  for out_type, passthrough_item in order:
    if out_type is None:
      merged_items.append(passthrough_item)
      continue
    chunks = grouped[out_type]
    first = chunks[0]
    if len(chunks) == 1:
      merged_items.append(first)
      continue
    combined = type(first)()
    combined.CopyFrom(first)
    arrays = [
        np.asarray(tensor_utils.unpack_proto(c.track_data.values))
        for c in chunks
    ]
    concat_arr = np.concatenate(arrays, axis=-1)
    compression_type: Any = (
        first.track_data.values.array.compression_type
        if first.track_data.values.HasField('array')
        else 0
    )
    packed_values, _ = tensor_utils.pack_tensor(
        concat_arr,
        bytes_per_chunk=0,
        compression_type=compression_type,
    )
    combined.track_data.values.CopyFrom(packed_values)
    del combined.track_data.metadata[:]
    for c in chunks:
      combined.track_data.metadata.extend(c.track_data.metadata)
    merged_items.append(combined)

  del repeated_outputs[:]
  repeated_outputs.extend(merged_items)


def merge_response_protos(results: Sequence[Any]) -> Any:
  """Merges streamed response protobuf chunks and concatenates split TrackData."""
  if not results:
    raise ValueError('Cannot merge empty response sequence.')
  if not isinstance(results[0], message.Message):
    return results[-1]
  merged = type(results[0])()
  if len(results) == 1:
    merged.CopyFrom(results[0])
  else:
    for item in results:
      merged.MergeFrom(item)
  for field_name in ('outputs', 'reference_outputs', 'alternate_outputs'):
    if hasattr(merged, field_name):
      _merge_repeated_outputs(getattr(merged, field_name))
  _normalize_strands_in_place(merged)
  _normalize_score_shapes_in_place(merged)
  return merged


class _WrappedCallStream(grpc.Call):
  """Wraps an underlying grpc.Call stream and deserializes response payloads."""

  def __init__(
      self,
      call: Any,
      response_deserializer: Callable[[bytes], Any] | None,
  ):
    self._call = call
    self._deserializer = response_deserializer
    self._iterator: Iterator[Any] | None = None

  def _generate(self) -> Iterator[Any]:
    for raw_resp in self._call:
      if self._deserializer is not None:
        yield self._deserializer(raw_resp.output)
      else:
        yield raw_resp.output

  def __iter__(self) -> Iterator[Any]:
    if self._iterator is None:
      self._iterator = self._generate()
    return self

  def __next__(self) -> Any:
    if self._iterator is None:
      self._iterator = self._generate()
    return next(self._iterator)

  def cancel(self) -> bool:
    return self._call.cancel()

  def is_active(self) -> bool:
    return self._call.is_active()

  def time_remaining(self) -> float | None:
    return self._call.time_remaining()

  def initial_metadata(self) -> Sequence[tuple[str, str | bytes]] | None:
    return self._call.initial_metadata()

  def trailing_metadata(self) -> Sequence[tuple[str, str | bytes]] | None:
    return self._call.trailing_metadata()

  def code(self) -> grpc.StatusCode | None:
    return self._call.code()

  def details(self) -> str | None:
    return self._call.details()

  def add_callback(self, callback: Callable[[Any], None]) -> bool:
    return self._call.add_callback(callback)


def _merge_endpoint_metadata(
    metadata: Sequence[tuple[str, str | bytes]] | None,
    endpoint: str,
) -> list[tuple[str, str | bytes]]:
  merged = list(metadata) if metadata else []
  if not any(k == 'x-goog-request-params' for k, _ in merged):
    merged.append(('x-goog-request-params', f'endpoint={endpoint}'))
  return merged


class _VertexAiUnaryUnaryMultiCallable(grpc.UnaryUnaryMultiCallable):
  """Maps DnaModelServiceV2 unary-unary RPC to Vertex AI StreamDirectRawPredict."""

  def __init__(
      self,
      underlying_stream_stream: grpc.StreamStreamMultiCallable,
      endpoint: str,
      method_name: str,
      request_serializer: Callable[[Any], bytes] | None,
      response_deserializer: Callable[[bytes], Any] | None,
  ):
    self._underlying_stream_stream = underlying_stream_stream
    self._endpoint = endpoint
    self._method_name = method_name
    self._serializer = request_serializer
    self._deserializer = response_deserializer

  def with_call(
      self,
      request: Any,
      timeout: float | None = None,
      metadata: Sequence[tuple[str, str | bytes]] | None = None,
      credentials: grpc.CallCredentials | None = None,
      wait_for_ready: bool | None = None,
      compression: grpc.Compression | None = None,
  ) -> tuple[Any, grpc.Call]:
    del wait_for_ready, compression

    def _invoke(target_method: str) -> tuple[list[Any], _WrappedCallStream]:
      def _request_generator() -> Iterator[
          prediction_service_pb2.StreamDirectRawPredictRequest
      ]:
        data = self._serializer(request) if self._serializer else request
        yield prediction_service_pb2.StreamDirectRawPredictRequest(
            endpoint=self._endpoint,
            method_name=target_method,
            input=data,
        )

      raw_call = self._underlying_stream_stream(
          _request_generator(),
          timeout=timeout,
          metadata=_merge_endpoint_metadata(metadata, self._endpoint),
          credentials=credentials,
      )
      wrapped = _WrappedCallStream(raw_call, self._deserializer)
      return list(wrapped), wrapped

    stream_method = _STREAMING_METHOD_MAP.get(self._method_name)
    if stream_method is not None:
      try:
        results, wrapped = _invoke(stream_method)
      except grpc.RpcError as e:
        code_fn = getattr(e, 'code', None)
        if callable(code_fn) and code_fn() == grpc.StatusCode.UNIMPLEMENTED:
          results, wrapped = _invoke(self._method_name)
        else:
          raise
    else:
      results, wrapped = _invoke(self._method_name)

    if not results:
      raise GrpcProxyRpcError(
          grpc.StatusCode.INTERNAL,
          f'Empty response stream from {self._method_name}',
      )
    return merge_response_protos(results), wrapped

  def __call__(
      self,
      request: Any,
      timeout: float | None = None,
      metadata: Sequence[tuple[str, str | bytes]] | None = None,
      credentials: grpc.CallCredentials | None = None,
      wait_for_ready: bool | None = None,
      compression: grpc.Compression | None = None,
  ) -> Any:
    response, _ = self.with_call(
        request,
        timeout=timeout,
        metadata=metadata,
        credentials=credentials,
        wait_for_ready=wait_for_ready,
        compression=compression,
    )
    return response

  def future(
      self,
      request: Any,
      timeout: float | None = None,
      metadata: Sequence[tuple[str, str | bytes]] | None = None,
      credentials: grpc.CallCredentials | None = None,
      wait_for_ready: bool | None = None,
      compression: grpc.Compression | None = None,
  ) -> Any:
    raise NotImplementedError('Async futures are not supported on proxy calls.')


class VertexAiPredictionChannel(grpc.Channel):
  """A gRPC channel translating DnaModelServiceV2 RPCs to StreamDirectRawPredict."""

  def __init__(self, underlying_channel: grpc.Channel, endpoint: str):
    self._channel = underlying_channel
    self._endpoint = endpoint
    self._stream_direct_raw_predict = underlying_channel.stream_stream(
        '/google.cloud.aiplatform.v1.PredictionService/StreamDirectRawPredict',
        request_serializer=prediction_service_pb2.StreamDirectRawPredictRequest.SerializeToString,
        response_deserializer=prediction_service_pb2.StreamDirectRawPredictResponse.FromString,
    )

  def unary_unary(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    del args, kwargs
    return _VertexAiUnaryUnaryMultiCallable(
        self._stream_direct_raw_predict,
        endpoint=self._endpoint,
        method_name=method,
        request_serializer=request_serializer,
        response_deserializer=response_deserializer,
    )

  def stream_stream(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    del method, request_serializer, response_deserializer, args, kwargs
    raise NotImplementedError(
        'DnaModelServiceV2 only supports unary-unary RPCs.'
    )

  def unary_stream(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    del method, request_serializer, response_deserializer, args, kwargs
    raise NotImplementedError(
        'DnaModelServiceV2 only supports unary-unary RPCs.'
    )

  def stream_unary(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    del method, request_serializer, response_deserializer, args, kwargs
    raise NotImplementedError(
        'DnaModelServiceV2 only supports unary-unary RPCs.'
    )

  def subscribe(
      self, callback: Callable[[Any], None], try_to_connect: bool = False
  ) -> None:
    self._channel.subscribe(callback, try_to_connect=try_to_connect)

  def unsubscribe(self, callback: Callable[[Any], None]) -> None:
    self._channel.unsubscribe(callback)

  def close(self) -> None:
    self._channel.close()

  def __enter__(self) -> 'VertexAiPredictionChannel':
    return self

  def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
    self.close()


class _DirectChunkedUnaryUnaryMultiCallable(grpc.UnaryUnaryMultiCallable):
  """Maps DnaModelServiceV2 unary-unary RPC to a direct unary-stream gRPC call."""

  def __init__(
      self,
      underlying_unary_stream: grpc.UnaryStreamMultiCallable,
      method_name: str,
      fallback_unary_unary: grpc.UnaryUnaryMultiCallable | None = None,
  ):
    self._underlying_unary_stream = underlying_unary_stream
    self._method_name = method_name
    self._fallback_unary_unary = fallback_unary_unary

  def with_call(
      self,
      request: Any,
      timeout: float | None = None,
      metadata: Sequence[tuple[str, str | bytes]] | None = None,
      credentials: grpc.CallCredentials | None = None,
      wait_for_ready: bool | None = None,
      compression: grpc.Compression | None = None,
  ) -> tuple[Any, grpc.Call]:
    try:
      raw_call = self._underlying_unary_stream(
          request,
          timeout=timeout,
          metadata=metadata,
          credentials=credentials,
          wait_for_ready=wait_for_ready,
          compression=compression,
      )
      results = list(raw_call)
    except grpc.RpcError as e:
      code_fn = getattr(e, 'code', None)
      if (
          self._fallback_unary_unary is not None
          and callable(code_fn)
          and code_fn() == grpc.StatusCode.UNIMPLEMENTED
      ):
        resp, call = self._fallback_unary_unary.with_call(
            request,
            timeout=timeout,
            metadata=metadata,
            credentials=credentials,
            wait_for_ready=wait_for_ready,
            compression=compression,
        )
        return merge_response_protos([resp]), call
      raise
    if not results:
      raise GrpcProxyRpcError(
          grpc.StatusCode.INTERNAL,
          f'Empty response stream from {self._method_name}',
      )
    return merge_response_protos(results), raw_call

  def __call__(
      self,
      request: Any,
      timeout: float | None = None,
      metadata: Sequence[tuple[str, str | bytes]] | None = None,
      credentials: grpc.CallCredentials | None = None,
      wait_for_ready: bool | None = None,
      compression: grpc.Compression | None = None,
  ) -> Any:
    response, _ = self.with_call(
        request,
        timeout=timeout,
        metadata=metadata,
        credentials=credentials,
        wait_for_ready=wait_for_ready,
        compression=compression,
    )
    return response

  def future(
      self,
      request: Any,
      timeout: float | None = None,
      metadata: Sequence[tuple[str, str | bytes]] | None = None,
      credentials: grpc.CallCredentials | None = None,
      wait_for_ready: bool | None = None,
      compression: grpc.Compression | None = None,
  ) -> Any:
    raise NotImplementedError(
        'Async futures are not supported on chunked calls.'
    )


class DirectChunkedGrpcChannel(grpc.Channel):
  """Direct gRPC channel adapter reassembling chunked server responses via unary_stream."""

  def __init__(self, underlying_channel: grpc.Channel):
    self._channel = underlying_channel

  def unary_unary(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    stream_method = _STREAMING_METHOD_MAP.get(method, method)
    underlying_unary_stream = self._channel.unary_stream(
        stream_method,
        request_serializer=request_serializer,
        response_deserializer=response_deserializer,
        *args,
        **kwargs,
    )
    fallback_unary_unary = self._channel.unary_unary(
        method,
        request_serializer=request_serializer,
        response_deserializer=response_deserializer,
        *args,
        **kwargs,
    )
    return _DirectChunkedUnaryUnaryMultiCallable(
        underlying_unary_stream,
        method_name=method,
        fallback_unary_unary=fallback_unary_unary,
    )

  def stream_stream(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    return self._channel.stream_stream(
        method,
        request_serializer=request_serializer,
        response_deserializer=response_deserializer,
        *args,
        **kwargs,
    )

  def unary_stream(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    return self._channel.unary_stream(
        method,
        request_serializer=request_serializer,
        response_deserializer=response_deserializer,
        *args,
        **kwargs,
    )

  def stream_unary(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    return self._channel.stream_unary(
        method,
        request_serializer=request_serializer,
        response_deserializer=response_deserializer,
        *args,
        **kwargs,
    )

  def subscribe(
      self, callback: Callable[[Any], None], try_to_connect: bool = False
  ) -> None:
    self._channel.subscribe(callback, try_to_connect=try_to_connect)

  def unsubscribe(self, callback: Callable[[Any], None]) -> None:
    self._channel.unsubscribe(callback)

  def close(self) -> None:
    self._channel.close()

  def __enter__(self) -> 'DirectChunkedGrpcChannel':
    return self

  def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
    self.close()


def _resolve_project(project: str | None, endpoint: str) -> str:
  """Resolves the GCP project ID from explicit argument, endpoint string, or ADC."""
  if project:
    return project
  match = re.search(r'projects/([^/]+)/locations/([^/]+)', endpoint)
  if match:
    return match.group(1)
  ded_match = re.search(
      r'^[0-9]+\.[a-z0-9-]+-([0-9]+)\.prediction\.vertexai\.goog',
      endpoint.strip().removeprefix('https://').removeprefix('http://'),
  )
  if ded_match:
    return ded_match.group(1)
  _, default_project = google.auth.default(
      scopes=['https://www.googleapis.com/auth/cloud-platform']
  )
  if default_project:
    return str(default_project)
  raise ValueError(
      'A GCP project ID is required when not embedded in the endpoint and not'
      ' discoverable from google.auth.default(). Pass project=... explicitly.'
  )


_SUPER_ENCODE_CELLS_ACCEPTS_KWARGS = (
    'progress_bar'
    in inspect.signature(dna_client.DnaClient.encode_cells).parameters
)


class CloudDnaClientMixin(dna_client.DnaClient):  # pyrefly: ignore[invalid-inheritance]
  """Shared cell-encoding batching for Cloud DnaClients."""

  def _encode_cell_batch(
      self,
      cell_batch: anndata.AnnData,
      *,
      progress_bar: bool,
      max_workers: int,
  ) -> np.ndarray:
    if _SUPER_ENCODE_CELLS_ACCEPTS_KWARGS:
      return super().encode_cells(
          cell_batch, progress_bar=progress_bar, max_workers=max_workers
      )
    return super().encode_cells(cell_batch)

  def encode_cells(
      self,
      cells: anndata.AnnData,
      *,
      progress_bar: bool = True,
      max_workers: int = 5,
  ) -> np.ndarray:
    n_obs = getattr(cells, 'n_obs', 0)
    if isinstance(n_obs, int) and n_obs > _MAX_ENCODE_CELLS_BATCH_SIZE:
      cell_chunks = [
          cells[start : start + _MAX_ENCODE_CELLS_BATCH_SIZE]
          for start in range(0, n_obs, _MAX_ENCODE_CELLS_BATCH_SIZE)
      ]
      with concurrent.futures.ThreadPoolExecutor(
          max_workers=max_workers
      ) as executor:
        futures = {
            executor.submit(
                self._encode_cell_batch,
                cell_chunk,
                progress_bar=False,
                max_workers=1,
            ): chunk_index
            for chunk_index, cell_chunk in enumerate(cell_chunks)
        }
        embeddings_by_chunk: dict[int, np.ndarray] = {}
        for future in tqdm.auto.tqdm(
            concurrent.futures.as_completed(futures),
            total=len(futures),
            disable=not progress_bar,
        ):
          embeddings_by_chunk[futures[future]] = future.result()
      return np.concatenate(
          [embeddings_by_chunk[i] for i in range(len(cell_chunks))], axis=0
      )
    return self._encode_cell_batch(
        cells, progress_bar=progress_bar, max_workers=max_workers
    )


class GrpcDnaClient(CloudDnaClientMixin):
  """AlphaGenome v2 DNA model gRPC client connected to Vertex AI IaaS or local container."""

  @classmethod
  def create_vertex_client(
      cls,
      endpoint: str = '',
      *,
      endpoint_id: str | None = None,
      project: str | None = None,
      location: str = 'us-central1',
      endpoint_address: str | None = None,
      service_account: str | None = None,
      token: str | None = None,
      credentials: google.auth.credentials.Credentials | None = None,
      model_version: ModelVersion | str | None = None,
      timeout: float | None = DEFAULT_TIMEOUT,
      options: list[tuple[str, Any]] | None = None,
      is_dedicated: bool = False,
  ) -> 'GrpcDnaClient':
    """Creates a gRPC client connected to a Vertex AI Prediction (IaaS) endpoint.

    Args:
      endpoint: Vertex AI Endpoint resource name (e.g.
        'projects/123/locations/us-central1/endpoints/456'), numeric endpoint
        ID, or dedicated endpoint DNS address.
      endpoint_id: Optional alias for `endpoint` (numeric endpoint ID or full
        resource name).
      project: GCP Project ID. Defaults to the project discovered via
        `google.auth.default()` when not embedded in `endpoint`.
      location: GCP Region/Location (default: 'us-central1').
      endpoint_address: Optional explicit host:port to connect to.
      service_account: Optional service account email for impersonation.
      token: Optional static OAuth2 bearer token.
      credentials: Optional google.auth credentials.
      model_version: Optional model checkpoint version (e.g. 'FOLD_1').
      timeout: Optional timeout for channel readiness probe.
      options: Optional custom gRPC channel options.
      is_dedicated: Whether this is a Dedicated Endpoint accessed directly.

    Returns:
      A configured GrpcDnaClient instance.
    """
    if endpoint_id is not None:
      endpoint = endpoint_id
    endpoint = endpoint.strip()
    if not endpoint:
      raise ValueError(
          'A Vertex AI endpoint ID, resource name, or dedicated DNS address is'
          ' required for create_vertex_client / create_grpc_client. For Vertex'
          ' AI OpenMaaS, use create_maas_client().'
      )

    auth_plugin = auth.GoogleAuthMetadataPlugin(
        credentials=credentials, service_account=service_account, token=token
    )
    is_dedicated_endpoint = is_dedicated or (
        '.prediction.vertexai.goog' in endpoint
    )

    channel_options = list(_DEFAULT_CHANNEL_OPTIONS)
    if options:
      channel_options.extend(options)
    call_creds = grpc.metadata_call_credentials(auth_plugin)
    ssl_creds = grpc.ssl_channel_credentials()
    composite_creds = grpc.composite_channel_credentials(ssl_creds, call_creds)

    if is_dedicated_endpoint:
      target_address = endpoint_address or (
          endpoint if ':' in endpoint else f'{endpoint}:443'
      )
      channel = grpc.secure_channel(
          target_address, composite_creds, options=channel_options
      )
      if timeout:
        grpc.channel_ready_future(channel).result(timeout=timeout)
      final_channel: grpc.Channel = DirectChunkedGrpcChannel(channel)
    else:
      if endpoint.startswith('projects/'):
        endpoint_resource_name = endpoint
        match = re.search(r'locations/([^/]+)/', endpoint)
        if match:
          location = match.group(1)
      else:
        resolved_project = _resolve_project(project, endpoint)
        endpoint_resource_name = f'projects/{resolved_project}/locations/{location}/endpoints/{endpoint}'

      target_address = endpoint_address or (
          f'{location}-aiplatform.googleapis.com:443'
      )
      channel = grpc.secure_channel(
          target_address, composite_creds, options=channel_options
      )
      if timeout:
        grpc.channel_ready_future(channel).result(timeout=timeout)
      final_channel = VertexAiPredictionChannel(
          underlying_channel=channel, endpoint=endpoint_resource_name
      )

    return cls(
        channel=final_channel,
        model_version=_parse_model_version(model_version),
    )

  @classmethod
  def create_local_client(
      cls,
      address: str = 'localhost:8081',
      *,
      model_version: ModelVersion | str | None = None,
      timeout: float | None = 10.0,
      options: list[tuple[str, Any]] | None = None,
  ) -> 'GrpcDnaClient':
    """Creates a client connected to an insecure local or VM gRPC server.

    Args:
      address: Host and port (e.g. 'localhost:8081').
      model_version: Optional model checkpoint version.
      timeout: Optional timeout for channel readiness probe.
      options: Optional custom gRPC channel options.

    Returns:
      A configured GrpcDnaClient instance.
    """
    channel_options = list(_DEFAULT_CHANNEL_OPTIONS)
    if options:
      channel_options.extend(options)

    channel = grpc.insecure_channel(address, options=channel_options)
    if timeout:
      grpc.channel_ready_future(channel).result(timeout=timeout)

    return cls(
        channel=DirectChunkedGrpcChannel(channel),
        model_version=_parse_model_version(model_version),
    )


CloudDnaClient = GrpcDnaClient
create_vertex_client = GrpcDnaClient.create_vertex_client
create_local_client = GrpcDnaClient.create_local_client


def create_grpc_client(
    endpoint: str = '',
    *,
    endpoint_id: str | None = None,
    project: str | None = None,
    location: str = 'us-central1',
    endpoint_address: str | None = None,
    service_account: str | None = None,
    token: str | None = None,
    credentials: google.auth.credentials.Credentials | None = None,
    model_version: ModelVersion | str | None = None,
    timeout: float | None = DEFAULT_TIMEOUT,
    options: list[tuple[str, Any]] | None = None,
    is_dedicated: bool = False,
    insecure: bool = False,
) -> GrpcDnaClient:
  """Convenience factory for creating an AlphaGenome v2 gRPC client for IaaS or local endpoints."""
  if insecure:
    target = endpoint_id or endpoint_address or endpoint or 'localhost:8081'
    return GrpcDnaClient.create_local_client(
        address=target,
        model_version=model_version,
        timeout=timeout,
        options=options,
    )
  return GrpcDnaClient.create_vertex_client(
      endpoint=endpoint,
      endpoint_id=endpoint_id,
      project=project,
      location=location,
      endpoint_address=endpoint_address,
      service_account=service_account,
      token=token,
      credentials=credentials,
      model_version=model_version,
      timeout=timeout,
      options=options,
      is_dedicated=is_dedicated,
  )
