# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""OpenMaaS client implementation wrapping HttpDnaClient with Science Token billing."""

import re
import threading
from typing import Any

import google.auth.credentials

try:
  from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk import auth  # pylint: disable=g-import-not-at-top
  from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top
  from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk.models import dna_client_http  # pylint: disable=g-import-not-at-top
except ImportError:
  from alphagenomev2_cloud_sdk import auth  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenomev2_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenomev2_cloud_sdk.models import dna_client_http  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

DEFAULT_MAAS_MODEL_NAME = 'alphagenome2-maas'

SEQUENCE_LENGTH_16KB = dna_client_http.SEQUENCE_LENGTH_16KB
SEQUENCE_LENGTH_100KB = dna_client_http.SEQUENCE_LENGTH_100KB
SEQUENCE_LENGTH_500KB = dna_client_http.SEQUENCE_LENGTH_500KB
SEQUENCE_LENGTH_1MB = dna_client_http.SEQUENCE_LENGTH_1MB
SUPPORTED_SEQUENCE_LENGTHS = dna_client_http.SUPPORTED_SEQUENCE_LENGTHS
MAX_CONDITIONING_CELLS = dna_client_http.MAX_CONDITIONING_CELLS
MAX_ISM_INTERVAL_WIDTH = dna_client_http.MAX_ISM_INTERVAL_WIDTH
MAX_VARIANT_SCORERS_PER_REQUEST = (
    dna_client_http.MAX_VARIANT_SCORERS_PER_REQUEST
)
DEFAULT_MAX_WORKERS = dna_client_http.DEFAULT_MAX_WORKERS

ModelVersion = dna_client_http.ModelVersion
Organism = dna_client_http.Organism
OutputType = dna_client_http.OutputType
Output = dna_client_http.Output
OutputMetadata = dna_client_http.OutputMetadata
VariantOutput = dna_client_http.VariantOutput
InputGradientsOutput = dna_client_http.InputGradientsOutput
validate_sequence_length = dna_client_http.validate_sequence_length

dna_client = dna_client_http.dna_client
dna_model = dna_client_http.dna_model
dna_output = dna_client_http.dna_output
gene_expression_data = dna_client_http.gene_expression_data
genome = dna_client_http.genome
httpx = dna_client_http.httpx
interval_scorers_lib = dna_client_http.interval_scorers_lib
junction_data = dna_client_http.junction_data
model_condition = dna_client_http.model_condition
ontology = dna_client_http.ontology
tensor_utils = dna_client_http.tensor_utils
track_data = dna_client_http.track_data
variant_scorers_lib = dna_client_http.variant_scorers_lib

MaasHttpRpcError = dna_client_http.HttpRpcError


class VertexAiMaasInvokeChannel(dna_client_http.VertexAiHttpChannel):  # pyrefly: ignore[invalid-inheritance]
  """A gRPC channel translating DnaModelServiceV2 RPCs to Vertex AI OpenMaaS HTTP POST with billing."""

  def __init__(
      self,
      *,
      model_name: str = DEFAULT_MAAS_MODEL_NAME,
      http_url: str,
      auth_plugin: auth.GoogleAuthMetadataPlugin,
      http_client: Any = None,
      include_maas_envelope: bool = True,
      default_timeout: float | None = None,
  ):
    super().__init__(
        http_url=http_url,
        auth_plugin=auth_plugin,
        http_client=http_client,
        default_timeout=default_timeout,
    )
    normalized_model = model_name.strip().removeprefix('google/')
    self._model_name = normalized_model
    self._include_maas_envelope = include_maas_envelope
    self._usage_lock = threading.Lock()
    self.last_usage_metadata: dict[str, Any] | None = None
    self.total_usage_metadata: dict[str, int] = {
        'inputTokenCount': 0,
        'outputTokenCount': 0,
    }

  def _record_usage(self, usage: dict[str, Any] | None) -> None:
    with self._usage_lock:
      self.last_usage_metadata = usage
      if isinstance(usage, dict):
        for key, val in usage.items():
          if isinstance(val, int):
            self.total_usage_metadata[key] = (
                self.total_usage_metadata.get(key, 0) + val
            )

  def get_last_usage_metadata(self) -> dict[str, Any] | None:
    """Returns a thread-safe snapshot of the most recent usageMetadata."""
    with self._usage_lock:
      return (
          dict(self.last_usage_metadata)
          if isinstance(self.last_usage_metadata, dict)
          else self.last_usage_metadata
      )

  def get_total_usage_metadata(self) -> dict[str, int]:
    """Returns a thread-safe copy of cumulative token usage counts."""
    with self._usage_lock:
      return dict(self.total_usage_metadata)

  def reset_usage_metadata(self) -> None:
    """Resets last and cumulative token usage counters."""
    with self._usage_lock:
      self.last_usage_metadata = None
      self.total_usage_metadata = {
          'inputTokenCount': 0,
          'outputTokenCount': 0,
      }

  def unary_unary(
      self,
      method: Any,
      request_serializer: Any = None,
      response_deserializer: Any = None,
      *args: Any,
      **kwargs: Any,
  ) -> Any:
    del args, kwargs
    return dna_client_http._VertexAiHttpUnaryUnaryMultiCallable(  # pylint: disable=protected-access
        self._invoke,
        method_name=method,
        request_serializer=request_serializer,
        response_deserializer=response_deserializer,
        model_name=self._model_name,
        include_maas_envelope=self._include_maas_envelope,
        track_usage=True,
        usage_callback=self._record_usage,
    )

  def __enter__(self) -> 'VertexAiMaasInvokeChannel':
    return self


def _is_generic_maas_target(target: str) -> bool:
  """Returns whether target refers to the shared OpenMaaS /endpoints/google route."""
  cleaned = target.strip().rstrip('/')
  return (
      cleaned
      in (
          '',
          'google',
          'alphagenome-maas',
          'alphagenome-v2-maas',
          'alphagenome2-maas',
          'google/alphagenome-maas',
          'google/alphagenome-v2-maas',
          'google/alphagenome2-maas',
          DEFAULT_MAAS_MODEL_NAME,
      )
      or cleaned.endswith('/endpoints/google')
      or '/endpoints/google/' in target
      or cleaned.endswith('/science/inference')
      or '/publishers/google/models/' in target
  )


def _resolve_maas_url(
    vertex_ai_url: str | None,
    endpoint: str,
    project: str | None,
    location: str,
) -> str:
  """Resolves the OpenMaaS HTTP URL."""
  target = (vertex_ai_url or endpoint or 'google').strip()
  if (
      vertex_ai_url
      and vertex_ai_url.strip().startswith(('https://', 'http://'))
      and (
          ':streamRawPredict' in vertex_ai_url
          or '/predict' in vertex_ai_url
          or '/science/inference' in vertex_ai_url
          or '/invoke/' in vertex_ai_url
      )
  ):
    return vertex_ai_url.strip()

  if not _is_generic_maas_target(target):
    return dna_client_http._resolve_http_url(  # pylint: disable=protected-access
        vertex_ai_url=vertex_ai_url,
        endpoint=endpoint,
        project=project,
        location=location,
    )

  scheme = 'http' if target.startswith('http://') else 'https'
  cleaned_no_scheme = (
      target.removeprefix('https://').removeprefix('http://').rstrip('/')
  )
  proj_loc_match = re.search(
      r'projects/([^/]+)/locations/([^/]+)', cleaned_no_scheme
  )
  if proj_loc_match:
    resolved_project = proj_loc_match.group(1)
    resolved_location = proj_loc_match.group(2)
  else:
    resolved_project = dna_client_grpc._resolve_project(project, target)  # pylint: disable=protected-access
    resolved_location = location

  parsed_host: str | None = None
  path = cleaned_no_scheme
  if target.startswith(('https://', 'http://')):
    if '/' in cleaned_no_scheme:
      host_part, path_part = cleaned_no_scheme.split('/', 1)
      path = '/' + path_part
    else:
      host_part = cleaned_no_scheme
      path = ''
    parsed_host = (
        host_part[:-4]
        if scheme == 'https' and host_part.endswith(':443')
        else host_part
    )

  if path.startswith('/v1/projects/') and '/endpoints/' in path:
    request_path = path
  elif path.startswith('v1/projects/') and '/endpoints/' in path:
    request_path = '/' + path
  else:
    request_path = (
        f'/v1/projects/{resolved_project}/locations/{resolved_location}'
        '/endpoints/google/science/inference'
    )

  host_for_url = parsed_host or f'{resolved_location}-aiplatform.googleapis.com'
  return f'{scheme}://{host_for_url}{request_path}'


class MaasDnaClient(dna_client_http.HttpDnaClient):  # pyrefly: ignore[invalid-inheritance]
  """AlphaGenome v2 OpenMaaS client wrapping HttpDnaClient with Science Token billing."""

  def __init__(
      self,
      http_client: dna_client_http.httpx.Client,
      vertex_ai_url: str,
      credentials: google.auth.credentials.Credentials | None = None,
      *,
      token: str | None = None,
      service_account: str | None = None,
      model_version: ModelVersion | str | None = None,
      timeout: float | None = None,
      maas_model_name: str = DEFAULT_MAAS_MODEL_NAME,
  ):
    self._maas_model_name = maas_model_name.strip().removeprefix('google/')
    auth_plugin = auth.GoogleAuthMetadataPlugin(
        credentials=credentials,
        service_account=service_account,
        token=token,
    )
    client_timeout = getattr(http_client, 'timeout', None)
    if timeout is not None:
      resolved_timeout = timeout
    elif isinstance(client_timeout, (int, float)):
      resolved_timeout = float(client_timeout)
    else:
      resolved_timeout = None
    maas_channel = VertexAiMaasInvokeChannel(
        model_name=maas_model_name,
        http_url=vertex_ai_url,
        auth_plugin=auth_plugin,
        http_client=http_client,
        include_maas_envelope=True,
        default_timeout=resolved_timeout,
    )
    super().__init__(
        http_client=http_client,
        vertex_ai_url=vertex_ai_url,
        credentials=credentials,
        token=token,
        service_account=service_account,
        model_version=model_version,
        timeout=resolved_timeout,
        channel=maas_channel,
    )

  @property
  def last_usage_metadata(self) -> dict[str, Any] | None:
    """Returns the most recent usageMetadata received from the OpenMaaS server."""
    get_fn = getattr(self._channel, 'get_last_usage_metadata', None)
    if callable(get_fn):
      return get_fn()
    return getattr(self._channel, 'last_usage_metadata', None)

  @property
  def total_usage_metadata(self) -> dict[str, int]:
    """Returns cumulative token counts across all requests made by this client."""
    get_fn = getattr(self._channel, 'get_total_usage_metadata', None)
    if callable(get_fn):
      return get_fn()
    return dict(getattr(self._channel, 'total_usage_metadata', {}))

  def reset_usage_metadata(self) -> None:
    """Resets last and cumulative token usage counters."""
    reset_fn = getattr(self._channel, 'reset_usage_metadata', None)
    if callable(reset_fn):
      reset_fn()


def create_maas_client(
    project: str | None = None,
    location: str = 'us-central1',
    *,
    endpoint: str = 'google',
    endpoint_id: str | None = None,
    vertex_ai_url: str | None = None,
    credentials: google.auth.credentials.Credentials | None = None,
    service_account: str | None = None,
    token: str | None = None,
    model_version: ModelVersion | str | None = None,
    timeout: float = 600.0,
    maas_model_name: str = DEFAULT_MAAS_MODEL_NAME,
) -> MaasDnaClient:
  """Creates an AlphaGenome v2 OpenMaaS client with Science Token billing enabled.

  Args:
    project: GCP Project ID. Defaults to the project discovered via
      `google.auth.default()` when not embedded in `endpoint` or
      `vertex_ai_url`.
    location: GCP Region/Location (default: 'us-central1').
    endpoint: OpenMaaS endpoint identifier or URL (default: 'google').
    endpoint_id: Optional alias for `endpoint`.
    vertex_ai_url: Optional full URL override for OpenMaaS HTTP POST
      predictions.
    credentials: Optional google.auth credentials.
    service_account: Optional service account email for impersonation.
    token: Optional static OAuth2 bearer token.
    model_version: Optional model checkpoint version (e.g. 'FOLD_1').
    timeout: HTTP request timeout in seconds (default: 600.0).
    maas_model_name: OpenMaaS publisher model identifier (default:
      'alphagenome2-maas').

  Returns:
    A configured MaasDnaClient instance.
  """
  if endpoint_id is not None:
    endpoint = endpoint_id

  resolved_url = _resolve_maas_url(
      vertex_ai_url=vertex_ai_url,
      endpoint=endpoint,
      project=project,
      location=location,
  )
  http_client = dna_client_http.httpx.Client(timeout=timeout)
  return MaasDnaClient(
      http_client=http_client,
      vertex_ai_url=resolved_url,
      credentials=credentials,
      token=token,
      service_account=service_account,
      model_version=model_version,
      timeout=timeout,
      maas_model_name=maas_model_name,
  )


create = create_maas_client

__all__ = [
    'DEFAULT_MAAS_MODEL_NAME',
    'DEFAULT_MAX_WORKERS',
    'InputGradientsOutput',
    'MAX_CONDITIONING_CELLS',
    'MAX_ISM_INTERVAL_WIDTH',
    'MAX_VARIANT_SCORERS_PER_REQUEST',
    'MaasDnaClient',
    'MaasHttpRpcError',
    'ModelVersion',
    'Organism',
    'Output',
    'OutputMetadata',
    'OutputType',
    'SEQUENCE_LENGTH_100KB',
    'SEQUENCE_LENGTH_16KB',
    'SEQUENCE_LENGTH_1MB',
    'SEQUENCE_LENGTH_500KB',
    'SUPPORTED_SEQUENCE_LENGTHS',
    'VariantOutput',
    'VertexAiMaasInvokeChannel',
    'create',
    'create_maas_client',
    'dna_client',
    'dna_model',
    'dna_output',
    'gene_expression_data',
    'genome',
    'httpx',
    'interval_scorers_lib',
    'junction_data',
    'model_condition',
    'ontology',
    'tensor_utils',
    'track_data',
    'validate_sequence_length',
    'variant_scorers_lib',
]
