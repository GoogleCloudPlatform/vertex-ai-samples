# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Client module re-exporting AlphaGenome v2 gRPC, HTTP, and OpenMaaS client utilities."""

try:
  from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top
  from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk.models import dna_client_http  # pylint: disable=g-import-not-at-top
  from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk.models import dna_client_maas  # pylint: disable=g-import-not-at-top
except ImportError:
  from alphagenomev2_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenomev2_cloud_sdk.models import dna_client_http  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenomev2_cloud_sdk.models import dna_client_maas  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

CloudDnaClient = dna_client_grpc.CloudDnaClient
GrpcDnaClient = dna_client_grpc.GrpcDnaClient
HttpDnaClient = dna_client_http.HttpDnaClient
MaasDnaClient = dna_client_maas.MaasDnaClient
ModelVersion = dna_client_grpc.ModelVersion
HttpRpcError = dna_client_http.HttpRpcError
MaasHttpRpcError = dna_client_maas.MaasHttpRpcError
VertexAiHttpChannel = dna_client_http.VertexAiHttpChannel
VertexAiMaasInvokeChannel = dna_client_maas.VertexAiMaasInvokeChannel
VertexAiPredictionChannel = dna_client_grpc.VertexAiPredictionChannel
DEFAULT_MAAS_MODEL_NAME = dna_client_maas.DEFAULT_MAAS_MODEL_NAME
create_grpc_client = dna_client_grpc.create_grpc_client
create_http_client = dna_client_http.create_http_client
create_maas_client = dna_client_maas.create_maas_client
create_vertex_client = dna_client_grpc.create_vertex_client
create_local_client = dna_client_grpc.create_local_client

__all__ = [
    'CloudDnaClient',
    'DEFAULT_MAAS_MODEL_NAME',
    'GrpcDnaClient',
    'HttpDnaClient',
    'HttpRpcError',
    'MaasDnaClient',
    'MaasHttpRpcError',
    'ModelVersion',
    'VertexAiHttpChannel',
    'VertexAiMaasInvokeChannel',
    'VertexAiPredictionChannel',
    'create_grpc_client',
    'create_http_client',
    'create_local_client',
    'create_maas_client',
    'create_vertex_client',
]
