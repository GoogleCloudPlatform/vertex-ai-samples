# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""AlphaGenome v2 Cloud SDK."""

import importlib
import typing
from typing import Any

if typing.TYPE_CHECKING:
  try:
    from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk import auth  # pylint: disable=g-import-not-at-top
    from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top
    from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk.models import dna_client_http  # pylint: disable=g-import-not-at-top
    from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk.models import dna_client_maas  # pylint: disable=g-import-not-at-top
  except ImportError:
    from alphagenomev2_cloud_sdk import auth  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
    from alphagenomev2_cloud_sdk.models import dna_client_grpc  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
    from alphagenomev2_cloud_sdk.models import dna_client_http  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
    from alphagenomev2_cloud_sdk.models import dna_client_maas  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

  GoogleAuthMetadataPlugin = auth.GoogleAuthMetadataPlugin
  CloudDnaClient = dna_client_grpc.CloudDnaClient
  GrpcDnaClient = dna_client_grpc.GrpcDnaClient
  HttpDnaClient = dna_client_http.HttpDnaClient
  MaasDnaClient = dna_client_maas.MaasDnaClient
  VertexAiHttpChannel = dna_client_http.VertexAiHttpChannel
  VertexAiMaasInvokeChannel = dna_client_maas.VertexAiMaasInvokeChannel
  VertexAiPredictionChannel = dna_client_grpc.VertexAiPredictionChannel
  create_grpc_client = dna_client_grpc.create_grpc_client
  create_http_client = dna_client_http.create_http_client
  create_maas_client = dna_client_maas.create_maas_client
  create_vertex_client = dna_client_grpc.create_vertex_client
  create_local_client = dna_client_grpc.create_local_client


def _import_submodule(rel_path: str) -> Any:
  try:
    return importlib.import_module(
        f'google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk.{rel_path}'
    )
  except ImportError:
    return importlib.import_module(f'alphagenomev2_cloud_sdk.{rel_path}')


_GRPC_EXPORTS = frozenset({
    'CloudDnaClient',
    'GrpcDnaClient',
    'VertexAiPredictionChannel',
    'create_grpc_client',
    'create_vertex_client',
    'create_local_client',
})

_HTTP_EXPORTS = frozenset({
    'HttpDnaClient',
    'VertexAiHttpChannel',
    'create_http_client',
})

_MAAS_EXPORTS = frozenset({
    'MaasDnaClient',
    'VertexAiMaasInvokeChannel',
    'create_maas_client',
})


def __getattr__(name: str) -> Any:  # pylint: disable=invalid-name
  if name == 'GoogleAuthMetadataPlugin':
    return getattr(_import_submodule('auth'), name)
  if name in ('dna_client_grpc', 'dna_client_http', 'dna_client_maas'):
    return _import_submodule(f'models.{name}')
  if name in _GRPC_EXPORTS:
    return getattr(_import_submodule('models.dna_client_grpc'), name)
  if name in _HTTP_EXPORTS:
    return getattr(_import_submodule('models.dna_client_http'), name)
  if name in _MAAS_EXPORTS:
    return getattr(_import_submodule('models.dna_client_maas'), name)
  raise AttributeError(f'module {__name__!r} has no attribute {name!r}')


__all__ = [
    'CloudDnaClient',
    'GoogleAuthMetadataPlugin',
    'GrpcDnaClient',
    'HttpDnaClient',
    'MaasDnaClient',
    'VertexAiHttpChannel',
    'VertexAiMaasInvokeChannel',
    'VertexAiPredictionChannel',
    'create_grpc_client',
    'create_http_client',
    'create_local_client',
    'create_maas_client',
    'create_vertex_client',
    'dna_client_grpc',
    'dna_client_http',
    'dna_client_maas',
]
