# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Sample client demonstrating AlphaGenome v2 predictions over gRPC."""

import time

from absl import app
from absl import flags
from absl import logging

try:
  from alphagenome.data import genome  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import dna_client  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import dna_model  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import dna_output  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
except ImportError:
  from alphagenome2.data import genome  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import dna_client  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import dna_model  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import dna_output  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

try:
  from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk import client  # pylint: disable=g-import-not-at-top
except ImportError:
  from alphagenomev2_cloud_sdk import client  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

_ENDPOINT = flags.DEFINE_string(
    'endpoint',
    None,
    'Vertex AI endpoint gRPC address or resource name. If not provided,'
    ' connects to local container.',
)
_SERVICE_ACCOUNT = flags.DEFINE_string(
    'service_account',
    None,
    'Optional service account for Vertex AI impersonation.',
)
_TOKEN = flags.DEFINE_string(
    'token',
    None,
    'Optional static OAuth2 bearer token.',
)
_LOCAL_ADDRESS = flags.DEFINE_string(
    'local_address',
    'localhost:8081',
    'Local container address if --endpoint is omitted.',
)


def main(argv):
  if len(argv) > 1:
    raise app.UsageError('Too many arguments.')

  if _ENDPOINT.value:
    logging.info('Connecting to Vertex AI endpoint: %s', _ENDPOINT.value)
    dna_model_client = client.CloudDnaClient.create_vertex_client(
        _ENDPOINT.value,
        service_account=_SERVICE_ACCOUNT.value,
        token=_TOKEN.value,
    )
  else:
    logging.info('Connecting to local container at: %s', _LOCAL_ADDRESS.value)
    dna_model_client = client.CloudDnaClient.create_local_client(
        _LOCAL_ADDRESS.value
    )

  sample_interval = genome.Interval(
      chromosome='chr19', start=41003816, end=41005864, strand='.'
  )
  sample_interval = sample_interval.resize(dna_client.SEQUENCE_LENGTH_16KB)

  logging.info('Predicting interval: %s', sample_interval)
  start_time = time.time()
  output = dna_model_client.predict_interval(
      interval=sample_interval,
      organism=dna_model.Organism.HOMO_SAPIENS,
      requested_outputs=[
          dna_output.OutputType.ATAC,
          dna_output.OutputType.RNA_SEQ,
          dna_output.OutputType.DNASE,
      ],
      condition='UBERON:0001114',
  )
  duration = time.time() - start_time
  logging.info('Prediction completed in %.2f seconds.', duration)
  logging.info('Output tracks: %s', output)


if __name__ == '__main__':
  app.run(main)
