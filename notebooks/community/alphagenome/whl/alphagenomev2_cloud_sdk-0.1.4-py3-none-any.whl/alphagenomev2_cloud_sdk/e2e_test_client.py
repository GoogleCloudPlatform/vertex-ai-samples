# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""End-to-end test client for validating AlphaGenome v2 gRPC endpoint methods."""

import time

from absl import app
from absl import flags
from absl import logging

try:
  from alphagenome.data import genome  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import dna_client  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import dna_model  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import dna_output  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome.models.v2 import variant_scorers as variant_scorers_lib  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
except ImportError:
  from alphagenome2.data import genome  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import dna_client  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import dna_model  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import dna_output  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]
  from alphagenome2.models.v2 import variant_scorers as variant_scorers_lib  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

try:
  from google3.cloud.ai.science.models.alphagenomev2.alphagenomev2_cloud_sdk.src.alphagenomev2_cloud_sdk import client  # pylint: disable=g-import-not-at-top
except ImportError:
  from alphagenomev2_cloud_sdk import client  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-import]

_ENDPOINT = flags.DEFINE_string(
    'endpoint',
    None,
    'Vertex AI endpoint gRPC address or resource name. If not provided,'
    ' connects to local container.',
)
_SERVICE_ACCOUNT = flags.DEFINE_string(
    'service_account',
    None,
    'Optional service account for Vertex AI impersonation.',
)
_TOKEN = flags.DEFINE_string(
    'token',
    None,
    'Optional static OAuth2 bearer token.',
)
_LOCAL_ADDRESS = flags.DEFINE_string(
    'local_address',
    'localhost:8081',
    'Local container address if --endpoint is omitted.',
)


def test_supported_conditions(
    dna_model_client: client.CloudDnaClient,
):
  """Tests supported_conditions unary-unary RPC."""
  logging.info('--- [1/6] Testing supported_conditions() ---')
  start_time = time.time()
  df = dna_model_client.supported_conditions(dna_model.Organism.HOMO_SAPIENS)
  duration = time.time() - start_time
  logging.info(
      'supported_conditions succeeded in %.2fs. Rows: %d',
      duration,
      len(df),
  )


def test_observed_metadata(
    dna_model_client: client.CloudDnaClient,
):
  """Tests observed_metadata unary-unary RPC."""
  logging.info('--- [2/6] Testing observed_metadata() ---')
  start_time = time.time()
  metadata = dna_model_client.observed_metadata(dna_model.Organism.HOMO_SAPIENS)
  duration = time.time() - start_time
  logging.info(
      'observed_metadata succeeded in %.2fs. Available tracks: ATAC=%s, RNA=%s,'
      ' DNASE=%s',
      duration,
      metadata.atac is not None,
      metadata.rna_seq is not None,
      metadata.dnase is not None,
  )


def test_predict_interval(
    dna_model_client: client.CloudDnaClient,
    interval: genome.Interval,
):
  """Tests predict_interval unary-unary RPC."""
  logging.info('--- [3/6] Testing predict_interval() ---')
  start_time = time.time()
  output = dna_model_client.predict_interval(
      interval=interval,
      organism=dna_model.Organism.HOMO_SAPIENS,
      requested_outputs=[
          dna_output.OutputType.ATAC,
          dna_output.OutputType.RNA_SEQ,
          dna_output.OutputType.DNASE,
      ],
      condition='UBERON:0001114',
  )
  duration = time.time() - start_time
  logging.info(
      'predict_interval succeeded in %.2fs. RNA shape: %s, ATAC shape: %s',
      duration,
      output.rna_seq.values.shape if output.rna_seq else None,
      output.atac.values.shape if output.atac else None,
  )


def test_predict_sequence(
    dna_model_client: client.CloudDnaClient,
):
  """Tests predict_sequence unary-unary RPC."""
  logging.info('--- [4/6] Testing predict_sequence() ---')
  seq_unit = 'ACGTACGTACGTACGT'
  test_seq = (seq_unit * (16384 // len(seq_unit)))[:16384]
  start_time = time.time()
  output = dna_model_client.predict_sequence(
      sequence=test_seq,
      organism=dna_model.Organism.HOMO_SAPIENS,
      requested_outputs=[
          dna_output.OutputType.RNA_SEQ,
          dna_output.OutputType.ATAC,
      ],
      condition='UBERON:0001114',
  )
  duration = time.time() - start_time
  logging.info(
      'predict_sequence succeeded in %.2fs. RNA shape: %s',
      duration,
      output.rna_seq.values.shape if output.rna_seq else None,
  )


def test_predict_variant(
    dna_model_client: client.CloudDnaClient,
    interval: genome.Interval,
):
  """Tests predict_variant unary-unary RPC."""
  logging.info('--- [5/6] Testing predict_variant() ---')
  test_variant = genome.Variant(
      chromosome='chr19',
      position=41004840,
      reference_bases='C',
      alternate_bases='T',
  )
  start_time = time.time()
  var_output = dna_model_client.predict_variant(
      interval=interval,
      variant=test_variant,
      organism=dna_model.Organism.HOMO_SAPIENS,
      requested_outputs=[dna_output.OutputType.RNA_SEQ],
      condition='UBERON:0001114',
  )
  duration = time.time() - start_time
  logging.info(
      'predict_variant succeeded in %.2fs. Ref RNA shape: %s, Alt RNA'
      ' shape: %s',
      duration,
      (
          var_output.reference.rna_seq.values.shape
          if var_output.reference and var_output.reference.rna_seq
          else None
      ),
      (
          var_output.alternate.rna_seq.values.shape
          if var_output.alternate and var_output.alternate.rna_seq
          else None
      ),
  )


def test_score_variant(
    dna_model_client: client.CloudDnaClient,
    interval: genome.Interval,
):
  """Tests score_variant unary-unary RPC."""
  logging.info('--- [6/6] Testing score_variant() ---')
  test_variant = genome.Variant(
      chromosome='chr19',
      position=41004840,
      reference_bases='C',
      alternate_bases='T',
  )
  start_time = time.time()
  scores = dna_model_client.score_variant(
      interval=interval,
      variant=test_variant,
      variant_scorers=[
          variant_scorers_lib.RECOMMENDED_VARIANT_SCORERS['RNA_SEQ']
      ],
      condition='UBERON:0001114',
      organism=dna_model.Organism.HOMO_SAPIENS,
  )
  duration = time.time() - start_time
  logging.info(
      'score_variant succeeded in %.2fs. Num score AnnData objects: %d',
      duration,
      len(scores),
  )
  for idx, s in enumerate(scores):
    logging.info(
        '  Score [%d] X shape: %s',
        idx,
        s.X.shape if s.X is not None else None,
    )


def main(argv):
  if len(argv) > 1:
    raise app.UsageError('Too many arguments.')

  if _ENDPOINT.value:
    logging.info('Connecting to Vertex AI endpoint: %s', _ENDPOINT.value)
    dna_model_client = client.CloudDnaClient.create_vertex_client(
        _ENDPOINT.value,
        service_account=_SERVICE_ACCOUNT.value,
        token=_TOKEN.value,
    )
  else:
    logging.info('Connecting to local container at: %s', _LOCAL_ADDRESS.value)
    dna_model_client = client.CloudDnaClient.create_local_client(
        _LOCAL_ADDRESS.value
    )

  sample_interval = genome.Interval(
      chromosome='chr19', start=41003816, end=41005864, strand='.'
  ).resize(dna_client.SEQUENCE_LENGTH_16KB)

  test_supported_conditions(dna_model_client)
  test_observed_metadata(dna_model_client)
  test_predict_interval(dna_model_client, sample_interval)
  test_predict_sequence(dna_model_client)
  test_predict_variant(dna_model_client, sample_interval)
  test_score_variant(dna_model_client, sample_interval)
  logging.info('=== All v2 endpoint tests passed successfully! ===')


if __name__ == '__main__':
  app.run(main)
